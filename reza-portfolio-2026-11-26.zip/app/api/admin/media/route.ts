import { getStore } from "@netlify/blobs";
import { ownerApiError, sameOriginRequest } from "@/lib/owner-auth";

const maxImageBytes = 8 * 1024 * 1024;
const maxAudioBytes = 20 * 1024 * 1024;
const imageTypes = new Map([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
]);

export async function POST(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const form = await request.formData();
    const file = form.get("file");
    const kind = form.get("kind") === "audio" ? "audio" : "image";
    if (!(file instanceof File)) return Response.json({ error: kind === "audio" ? "Pilih file MP3 terlebih dahulu." : "Pilih file foto terlebih dahulu." }, { status: 400 });
    let extension: string;
    let contentType: string;
    if (kind === "audio") {
      const isMp3Name = file.name.toLowerCase().endsWith(".mp3");
      const isMp3Type = !file.type || ["audio/mpeg", "audio/mp3", "application/octet-stream"].includes(file.type);
      if (!isMp3Name || !isMp3Type) return Response.json({ error: "Gunakan file audio berformat MP3." }, { status: 400 });
      if (file.size > maxAudioBytes) return Response.json({ error: "Ukuran file MP3 maksimal 20 MB." }, { status: 413 });
      extension = "mp3";
      contentType = "audio/mpeg";
    } else {
      const imageExtension = imageTypes.get(file.type);
      if (!imageExtension) return Response.json({ error: "Gunakan foto JPG, PNG, atau WebP." }, { status: 400 });
      if (file.size > maxImageBytes) return Response.json({ error: "Ukuran foto maksimal 8 MB." }, { status: 413 });
      extension = imageExtension;
      contentType = file.type;
    }
    const id = `${crypto.randomUUID()}.${extension}`;
    await getStore("media").set(id, file, { metadata: { contentType } });
    return Response.json({ src: `/api/media/${id}` }, { status: 201, headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "Foto belum dapat diunggah." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const body = await request.json() as { src?: unknown };
    if (typeof body.src !== "string" || !/^\/api\/media\/[a-f0-9-]+\.(?:jpe?g|png|webp|mp3)$/i.test(body.src)) {
      return Response.json({ error: "Media tidak dikenal." }, { status: 400 });
    }
    await getStore("media").delete(body.src.slice("/api/media/".length));
    return Response.json({ deleted: true });
  } catch {
    return Response.json({ error: "Media belum dapat dihapus." }, { status: 400 });
  }
}
