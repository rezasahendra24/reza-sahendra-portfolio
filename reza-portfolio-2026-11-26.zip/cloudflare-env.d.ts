declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    OWNER_EMAIL?: string;
    ADMIN_PIN_VERIFIER?: string;
    ADMIN_SESSION_SECRET?: string;
  }
}
