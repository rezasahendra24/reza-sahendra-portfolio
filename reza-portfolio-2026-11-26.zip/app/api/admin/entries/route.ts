import { asc, desc, eq, max } from "drizzle-orm";
import { getDb } from "@/db";
import { entries } from "@/db/schema";
import { ownerApiError, sameOriginRequest } from "@/lib/owner-auth";

export async function GET(request: Request) {
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const rows = await getDb().select().from(entries).orderBy(asc(entries.sortOrder), desc(entries.updatedAt)).limit(100);
    return Response.json({ entries: rows }, { headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "Database belum siap." }, { status: 503 });
  }
}

export async function POST(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const body = await request.json() as Record<string, unknown>;
    const kind = body.kind === "project" || body.kind === "post" ? body.kind : null;
    const title = typeof body.title === "string" ? body.title.trim().slice(0, 180) : "";
    const summary = typeof body.summary === "string" ? body.summary.trim().slice(0, 500) : "";
    const content = typeof body.content === "string" ? body.content.trim().slice(0, 20000) : "";
    const category = typeof body.category === "string" ? body.category.trim().slice(0, 80) : "";
    const externalUrl = safeUrl(body.externalUrl);
    const coverImage = kind === "project" ? safeImageSource(body.coverImage) : null;
    const audioSrc = kind === "project" ? safeAudioSource(body.audioSrc) : null;
    if (kind === "project" && typeof body.coverImage === "string" && body.coverImage && !coverImage) return Response.json({ error: "Foto karya tidak valid." }, { status: 400 });
    if (kind === "project" && typeof body.audioSrc === "string" && body.audioSrc && !audioSrc) return Response.json({ error: "File audio harus berupa MP3 yang diunggah ke situs." }, { status: 400 });
    const status = body.status === "published" ? "published" : "draft";
    if (!kind || !title) return Response.json({ error: "Jenis dan judul wajib diisi." }, { status: 400 });
    const rawSlug = typeof body.slug === "string" && body.slug.trim() ? body.slug : title;
    const slug = slugify(rawSlug);
    if (!slug) return Response.json({ error: "Slug tidak valid." }, { status: 400 });
    const now = new Date().toISOString();
    let sortOrder = 0;
    if (kind === "project") {
      const [row] = await getDb().select({ maxSortOrder: max(entries.sortOrder) }).from(entries).where(eq(entries.kind, "project"));
      sortOrder = Number(row?.maxSortOrder ?? -1) + 1;
    }
    const [created] = await getDb().insert(entries).values({ kind, title, slug, summary, content, category, externalUrl, coverImage, audioSrc, status, sortOrder, updatedAt: now }).returning();
    return Response.json({ entry: created }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error && error.message.includes("UNIQUE") ? "Slug sudah digunakan. Pilih slug lain." : "Konten belum dapat disimpan.";
    return Response.json({ error: message }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const body = await request.json() as { kind?: unknown; ids?: unknown };
    if (body.kind !== "project" || !Array.isArray(body.ids) || body.ids.length > 100) {
      return Response.json({ error: "Daftar urutan karya tidak valid." }, { status: 400 });
    }
    const ids = body.ids as unknown[];
    if (ids.some((id) => typeof id !== "number" || !Number.isSafeInteger(id) || id < 1) || new Set(ids).size !== ids.length) {
      return Response.json({ error: "Daftar urutan karya tidak valid." }, { status: 400 });
    }
    const db = getDb();
    const rows = await db.select({ id: entries.id }).from(entries).where(eq(entries.kind, "project"));
    const existing = new Set(rows.map((row) => row.id));
    if (ids.length !== existing.size || ids.some((id) => !existing.has(Number(id)))) {
      return Response.json({ error: "Daftar karya berubah. Muat ulang lalu coba lagi." }, { status: 409 });
    }
    if (!ids.length) return Response.json({ updated: 0 });
    await db.transaction(async (tx) => {
      for (const [index, id] of ids.entries()) await tx.update(entries).set({ sortOrder: index }).where(eq(entries.id, Number(id)));
    });
    return Response.json({ updated: ids.length });
  } catch {
    return Response.json({ error: "Urutan karya belum dapat disimpan." }, { status: 400 });
  }
}

function slugify(value: string) {
  return value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 100);
}

function safeUrl(value: unknown): string | null {
  if (typeof value !== "string" || !value.trim()) return null;
  try {
    const url = new URL(value.trim());
    return url.protocol === "https:" ? url.toString() : null;
  } catch { return null; }
}

function safeImageSource(value: unknown): string | null {
  if (typeof value !== "string" || !value) return null;
  if (/^\/api\/media\/[a-f0-9-]+\.(?:jpe?g|png|webp)$/i.test(value)) return value;
  if (/^\/media\/[a-f0-9-]+\.(?:jpe?g|png|webp)$/i.test(value)) return value;
  if (/^\/images\/[a-z0-9/_-]+\.(?:jpe?g|png|webp)$/i.test(value) && !value.includes("..")) return value;
  return null;
}

function safeAudioSource(value: unknown): string | null {
  if (typeof value !== "string" || !value) return null;
  return /^\/(?:api\/)?media\/[a-f0-9-]+\.mp3$/i.test(value) ? value : null;
}
