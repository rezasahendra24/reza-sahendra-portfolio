import { asc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { galleryPhotos, siteSettings } from "@/db/schema";
import { defaultGalleryPhotos, defaultSiteContent, normalizeSiteContent, type GalleryPhoto, type SiteContent } from "@/lib/site-content-defaults";

export { defaultGalleryPhotos, defaultSiteContent, normalizeSiteContent } from "@/lib/site-content-defaults";
export type { GalleryPhoto, SiteContent } from "@/lib/site-content-defaults";

export async function getSiteContent(): Promise<SiteContent> {
  try {
    const [row] = await getDb().select().from(siteSettings).where(eq(siteSettings.key, "content")).limit(1);
    return row ? normalizeSiteContent(JSON.parse(row.value)) : defaultSiteContent;
  } catch {
    return defaultSiteContent;
  }
}

export async function getGalleryPhotos(): Promise<GalleryPhoto[]> {
  try {
    const rows = await getDb().select({ src: galleryPhotos.src, width: galleryPhotos.width, height: galleryPhotos.height, alt: galleryPhotos.alt, caption: galleryPhotos.caption })
      .from(galleryPhotos).orderBy(asc(galleryPhotos.sortOrder), asc(galleryPhotos.id));
    if (rows.length) return rows;
    const [saved] = await getDb().select({ key: siteSettings.key }).from(siteSettings).where(eq(siteSettings.key, "gallery_saved")).limit(1);
    return saved ? [] : defaultGalleryPhotos;
  } catch {
    return defaultGalleryPhotos;
  }
}
