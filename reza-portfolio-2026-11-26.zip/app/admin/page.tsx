/* eslint-disable @next/next/no-html-link-for-pages -- Native navigation avoids the current vinext Link click error. */
import { headers } from "next/headers";
import type { Metadata } from "next";
import { ownerId } from "@/lib/owner-auth";
import { hasValidAdminSession } from "@/lib/admin-session";
import AdminPanel from "./admin-panel";
import AdminPinForm from "./admin-login-form";
import AdminLogoutButton from "./admin-logout-button";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { robots: { index: false, follow: false } };

export default async function AdminPage() {
  const requestHeaders = await headers();
  const owner = ownerId(requestHeaders);
  if (!owner) return (
    <main className="admin-shell"><section className="admin-denied">
      <h1>Halaman ini untuk pemilik situs.</h1>
      <a className="button button-dark" href="/">Kembali ke situs</a>
    </section></main>
  );
  if (!await hasValidAdminSession(requestHeaders.get("cookie"), owner)) {
    return <AdminPinForm/>;
  }
  return (
    <main className="admin-shell">
      <header className="admin-topbar">
        <a className="wordmark" href="/"><span className="mark">R.</span><span>REZA SAHENDRA</span></a>
        <div className="admin-user"><a href="/">Lihat situs</a><AdminLogoutButton/></div>
      </header>
      <section className="admin-content"><p className="eyebrow">PENGELOLAAN SITUS</p><h1>Ruang admin.</h1>
        <p className="admin-lede">Edit setiap bagian situs melalui tab per halaman, termasuk teks, tautan sosial, karya, tulisan, foto, dan pesan.</p>
        <AdminPanel/>
      </section>
    </main>
  );
}
