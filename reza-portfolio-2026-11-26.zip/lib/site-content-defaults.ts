export const defaultSiteContent = {
  general: {
    brandMark: "R.",
    logoImage: "",
    logoImageAlt: "Logo Reza Sahendra",
    brandName: "REZA SAHENDRA",
    siteTitle: "Reza Sahendra — Portofolio dan Catatan",
    siteDescription: "Portofolio, profil profesional, dan blog pribadi Reza Sahendra.",
    footerNote: "Ruang untuk terus bertumbuh.",
    profileCaption: "PROFIL",
    adminLinkLabel: "ADMIN",
  },
  home: {
    navLabel: "Beranda",
    eyebrow: "PORTOFOLIO · PROFIL · JURNAL",
    titleFirst: "Halo, saya",
    titleSecond: "Reza Sahendra.",
    intro: "Ini ruang untuk memperkenalkan diri, menyimpan karya, dan berbagi hal-hal yang sedang saya pikirkan.",
    primaryCta: "Jelajahi karya",
    secondaryCta: "Kenali saya",
    note: "Ruang untuk perjalanan, proses, dan hal baru.",
    artLabel: "RUANG BERKARYA",
    artCaption: "PORTOFOLIO · CATATAN · CERITA",
    indexLabel: "01 / 03",
    indexCaption: "RUANG PRIBADI",
    heroImage: "",
    heroImageAlt: "Foto pada bagian pembuka",
    heroAspect: "4:5",
  },
  about: {
    navLabel: "Tentang",
    kicker: "TENTANG SAYA",
    titleFirst: "Perjalanan yang terus",
    titleSecond: "bertumbuh.",
    lead: "Saya Reza, ASN PPPK Paruh Waktu di Dinas Pariwisata, Kebudayaan, Kepemudaan dan Olahraga Kabupaten Bengkalis.",
    agencyUrl: "https://disparbudpora.bengkaliskab.go.id/#",
    body: "Di luar pekerjaan, saya menjalankan peran Direktur Operasional di Ojek Bengkalis Simpang dan Direktur Utama di WeSolve Tech. Situs ini menjadi ruang untuk memperkenalkan perjalanan, karya, serta hal-hal yang saya pelajari.",
    linkLabel: "Sapa saya melalui kanal pilihanmu",
    portraitSrc: "/images/reza-sahendra.jpg",
    portraitAspect: "1:1",
  },
  works: {
    navLabel: "Karya",
    kicker: "HAL YANG SAYA BUAT",
    title: "Karya pilihan",
    description: "Proyek dan pengalaman yang ingin saya ceritakan lebih dekat.",
    showDefaultProjects: true,
    cardPrefix: "KARYA",
    projectLinkLabel: "Lihat detail",
    emptyTitle: "Karya akan segera hadir.",
    emptyDescription: "Tambahkan proyek atau pengalaman melalui halaman admin.",
  },
  gallery: {
    navLabel: "Galeri",
    kicker: "ALBUM PRIBADI",
    title: "Potongan cerita",
    description: "Beberapa momen dari masa sekolah, perjalanan, dan pencapaian.",
    emptyTitle: "Belum ada foto di galeri.",
    emptyDescription: "Foto akan tampil di sini setelah ditambahkan melalui halaman admin.",
    closeLabel: "Tutup",
    previousLabel: "Sebelumnya",
    nextLabel: "Berikutnya",
    openPhotoLabel: "Buka foto",
  },
  blog: {
    navLabel: "Catatan",
    kicker: "DARI BUKU CATATAN",
    titleFirst: "Catatan dan",
    titleSecond: "pemikiran",
    description: "Blog pribadi untuk menyimpan pemikiran, temuan, dan cerita di balik proses.",
    emptyTitle: "Catatan pertama akan segera hadir.",
    emptyDescription: "Tulis dan terbitkan artikel melalui halaman admin untuk mulai mengisi blog ini.",
    categoryFallback: "CATATAN",
    backLabel: "Kembali ke catatan",
    allPostsLabel: "Semua catatan",
  },
  contact: {
    navLabel: "Kontak",
    kicker: "SELALU TERBUKA UNTUK OBROLAN",
    titleFirst: "Mulai dari",
    titleSecond: "sebuah sapaan.",
    description: "Temukan dan hubungi saya melalui kanal berikut.",
    formKicker: "KIRIM PESAN",
    formTitleFirst: "Ada yang ingin",
    formTitleSecond: "disampaikan?",
    formDescription: "Pesanmu tersimpan secara privat dan hanya dapat dibaca melalui halaman admin.",
    nameLabel: "Nama",
    emailLabel: "Email",
    messageLabel: "Pesan",
    namePlaceholder: "Nama kamu",
    emailPlaceholder: "nama@email.com",
    messagePlaceholder: "Tuliskan pesanmu di sini",
    submitLabel: "Kirim pesan",
    sendingLabel: "Mengirim…",
    sentMessage: "Pesan terkirim. Terima kasih sudah menyapa.",
    errorMessage: "Pesan belum terkirim. Coba lagi sebentar.",
  },
  navigation: {
    panelTitle: "JELAJAHI HALAMAN",
    contactCta: "Mari terhubung",
  },
  socials: {
    instagramLabel: "Instagram",
    instagramUrl: "https://www.instagram.com/reza_sahendra/",
    facebookLabel: "Facebook",
    facebookUrl: "https://www.facebook.com/reza.sahendra.5",
    linkedinLabel: "LinkedIn",
    linkedinUrl: "https://www.linkedin.com/in/reza-sahendra-330968221/",
    youtubeLabel: "YouTube",
    youtubeUrl: "https://www.youtube.com/@rezasahendra4646",
    whatsappLabel: "WhatsApp",
    whatsappPhone: "082386095013",
    socialLinks: [
      { id: "instagram", label: "Instagram", url: "https://www.instagram.com/reza_sahendra/" },
      { id: "facebook", label: "Facebook", url: "https://www.facebook.com/reza.sahendra.5" },
      { id: "linkedin", label: "LinkedIn", url: "https://www.linkedin.com/in/reza-sahendra-330968221/" },
      { id: "youtube", label: "YouTube", url: "https://www.youtube.com/@rezasahendra4646" },
      { id: "whatsapp", label: "WhatsApp", url: "https://wa.me/6282386095013" },
    ],
    openLabel: "Buka profil",
  },
};

export type SiteContent = typeof defaultSiteContent;
export type SocialLink = SiteContent["socials"]["socialLinks"][number];

export const defaultGalleryPhotos = [
  { src: "/images/gallery/masa-muda-1.jpg", width: 720, height: 480, alt: "Reza Sahendra semasa muda, berpose di depan foto tokoh", caption: "Potret masa muda" },
  { src: "/images/gallery/masa-muda-2.jpg", width: 1280, height: 960, alt: "Reza Sahendra semasa muda di depan pintu ukir", caption: "Kenangan pribadi" },
  { src: "/images/gallery/perpisahan-sman2-bengkalis.jpg", width: 4288, height: 2848, alt: "Reza Sahendra mengenakan busana adat pada acara sekolah", caption: "Perpisahan · SMAN 2 Bengkalis" },
  { src: "/images/gallery/yudisium-politeknik-negeri-bengkalis.jpg", width: 4016, height: 6016, alt: "Reza Sahendra mengenakan selempang yudisium", caption: "Yudisium · Politeknik Negeri Bengkalis" },
];

export type GalleryPhoto = typeof defaultGalleryPhotos[number];

export function normalizeSiteContent(input: unknown): SiteContent {
  let source = input && typeof input === "object" ? input as Record<string, unknown> : {};
  const incomingSocials = source.socials && typeof source.socials === "object" ? source.socials as Record<string, unknown> : {};
  if (!Array.isArray(incomingSocials.socialLinks)) {
    const value = (key: string, fallback: string) => typeof incomingSocials[key] === "string" ? (incomingSocials[key] as string).trim() : fallback;
    const phoneDigits = value("whatsappPhone", "082386095013").replace(/\D/g, "");
    const whatsappNumber = phoneDigits.startsWith("0") ? `62${phoneDigits.slice(1)}` : phoneDigits;
    const legacyLinks = [
      { id: "instagram", label: value("instagramLabel", "Instagram"), url: value("instagramUrl", "https://www.instagram.com/reza_sahendra/") },
      { id: "facebook", label: value("facebookLabel", "Facebook"), url: value("facebookUrl", "https://www.facebook.com/reza.sahendra.5") },
      { id: "linkedin", label: value("linkedinLabel", "LinkedIn"), url: value("linkedinUrl", "https://www.linkedin.com/in/reza-sahendra-330968221/") },
      { id: "youtube", label: value("youtubeLabel", "YouTube"), url: value("youtubeUrl", "https://www.youtube.com/@rezasahendra4646") },
      { id: "whatsapp", label: value("whatsappLabel", "WhatsApp"), url: whatsappNumber ? `https://wa.me/${whatsappNumber}` : "" },
    ].filter((link) => link.label && link.url);
    source = { ...source, socials: { ...incomingSocials, socialLinks: legacyLinks } };
  }
  const merge = (defaults: unknown, candidate: unknown): unknown => {
    if (typeof defaults === "string") return typeof candidate === "string" ? candidate.trim().slice(0, 4000) : defaults;
    if (typeof defaults === "boolean") return typeof candidate === "boolean" ? candidate : defaults;
    if (Array.isArray(defaults)) {
      const values = Array.isArray(candidate) ? candidate : defaults;
      const usedIds = new Set<string>();
      return values.slice(0, 20).flatMap((item, index) => {
        if (!item || typeof item !== "object" || Array.isArray(item)) return [];
        const value = item as Record<string, unknown>;
        const label = typeof value.label === "string" ? value.label.trim().slice(0, 60) : "";
        const url = typeof value.url === "string" ? value.url.trim().slice(0, 500) : "";
        let safeUrl = "";
        try { const parsed = new URL(url); if (parsed.protocol === "https:") safeUrl = parsed.toString(); } catch { /* invalid social link */ }
        if (!label || !safeUrl) return [];
        const rawId = typeof value.id === "string" ? value.id.trim().slice(0, 80) : "";
        let id = rawId && /^[a-z0-9_-]+$/i.test(rawId) ? rawId : `social-${index + 1}`;
        while (usedIds.has(id)) id = `social-${id}`.slice(0, 80);
        usedIds.add(id);
        return [{ id, label, url: safeUrl }];
      });
    }
    if (!defaults || typeof defaults !== "object") return defaults;
    const incoming = candidate && typeof candidate === "object" ? candidate as Record<string, unknown> : {};
    return Object.fromEntries(Object.entries(defaults).map(([key, value]) => [key, merge(value, incoming[key])]));
  };
  return merge(defaultSiteContent, source) as SiteContent;
}
