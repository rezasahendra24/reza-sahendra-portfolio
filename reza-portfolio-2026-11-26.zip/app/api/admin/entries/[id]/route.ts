import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { entries } from "@/db/schema";
import { ownerApiError, sameOriginRequest } from "@/lib/owner-auth";

type RouteContext = { params: Promise<{ id: string }> };

export async function PUT(request: Request, context: RouteContext) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  const denied = await ownerApiError(request);
  if (denied) return denied;
  const { id: rawId } = await context.params;
  const id = Number(rawId);
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "ID tidak valid." }, { status: 400 });
  try {
    const body = await request.json() as Record<string, unknown>;
    const title = typeof body.title === "string" ? body.title.trim().slice(0, 180) : "";
    if (!title) return Response.json({ error: "Judul wajib diisi." }, { status: 400 });
    const slugValue = typeof body.slug === "string" && body.slug.trim() ? body.slug : title;
    const slug = slugValue.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 100);
    const externalUrl = safeUrl(body.externalUrl);
    const coverImage = body.kind === "project" ? safeImageSource(body.coverImage) : null;
    const audioSrc = body.kind === "project" ? safeAudioSource(body.audioSrc) : null;
    if (body.kind === "project" && typeof body.coverImage === "string" && body.coverImage && !coverImage) return Response.json({ error: "Foto karya tidak valid." }, { status: 400 });
    if (body.kind === "project" && typeof body.audioSrc === "string" && body.audioSrc && !audioSrc) return Response.json({ error: "File audio harus berupa MP3 yang diunggah ke situs." }, { status: 400 });
    const [updated] = await getDb().update(entries).set({
      title, slug,
      summary: typeof body.summary === "string" ? body.summary.trim().slice(0, 500) : "",
      content: typeof body.content === "string" ? body.content.trim().slice(0, 20000) : "",
      category: typeof body.category === "string" ? body.category.trim().slice(0, 80) : "",
      externalUrl,
      coverImage,
      audioSrc,
      status: body.status === "published" ? "published" : "draft",
      updatedAt: new Date().toISOString(),
    }).where(eq(entries.id, id)).returning();
    if (!updated) return Response.json({ error: "Konten tidak ditemukan." }, { status: 404 });
    return Response.json({ entry: updated });
  } catch (error) {
    const message = error instanceof Error && error.message.includes("UNIQUE") ? "Slug sudah digunakan. Pilih slug lain." : "Konten belum dapat diperbarui.";
    return Response.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(request: Request, context: RouteContext) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  const denied = await ownerApiError(request);
  if (denied) return denied;
  const { id: rawId } = await context.params;
  const id = Number(rawId);
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "ID tidak valid." }, { status: 400 });
  const [deleted] = await getDb().delete(entries).where(eq(entries.id, id)).returning({ id: entries.id });
  if (!deleted) return Response.json({ error: "Konten tidak ditemukan." }, { status: 404 });
  return Response.json({ ok: true });
}

function safeUrl(value: unknown): string | null {
  if (typeof value !== "string" || !value.trim()) return null;
  try { const url = new URL(value.trim()); return url.protocol === "https:" ? url.toString() : null; }
  catch { return null; }
}

function safeImageSource(value: unknown): string | null {
  if (typeof value !== "string" || !value) return null;
  if (/^\/api\/media\/[a-f0-9-]+\.(?:jpe?g|png|webp)$/i.test(value)) return value;
  if (/^\/media\/[a-f0-9-]+\.(?:jpe?g|png|webp)$/i.test(value)) return value;
  if (/^\/images\/[a-z0-9/_-]+\.(?:jpe?g|png|webp)$/i.test(value) && !value.includes("..")) return value;
  return null;
}

function safeAudioSource(value: unknown): string | null {
  if (typeof value !== "string" || !value) return null;
  return /^\/(?:api\/)?media\/[a-f0-9-]+\.mp3$/i.test(value) ? value : null;
}
