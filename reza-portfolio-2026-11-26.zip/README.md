# Portofolio Reza Sahendra

Situs portofolio, profil profesional, galeri, karya, dan catatan pribadi Reza Sahendra. Situs aktif: [rezasahendra.netlify.app](https://rezasahendra.netlify.app/).

## Mulai dari sini

| Kebutuhan | Lokasi |
| --- | --- |
| Peta kode dan data | [docs/CONTENT_MAP.md](docs/CONTENT_MAP.md) |
| Cara membuat dan memulihkan cadangan | [docs/BACKUP_AND_RESTORE.md](docs/BACKUP_AND_RESTORE.md) |
| Ekspor konten situs per tanggal | [backups/2026-11-26](backups/2026-11-26) |
| Halaman publik | `app/page.tsx`, `app/catatan`, `app/jurnal` |
| Editor admin | `app/admin`, `app/api/admin` |
| Skema dan migrasi database | `db/schema.ts`, `drizzle/` |
| Foto dan media bawaan | `public/images`, `public/media` |

## Teknologi

Next.js 16, React 19, TypeScript, Netlify, Netlify Database (PostgreSQL), Netlify Blobs, dan Drizzle ORM. Konfigurasi deploy ada di `netlify.toml`. Konten yang disunting di admin disimpan di database; media yang diunggah disimpan di Netlify Blobs. Karena itu, kode saja tidak cukup untuk memulihkan isi situs.

## Menjalankan secara lokal

Perlu Node.js 22 atau lebih baru. Jalankan `npm ci`, lalu `npm run dev`. Halaman yang memakai database memerlukan lingkungan Netlify Database yang terhubung; jangan menganggap database lokal berisi data produksi. `npm run build` memeriksa paket sebelum deploy.

## Privasi dan rahasia

Repositori ini **privat** karena dapat berisi draf, foto, dan ekspor pesan. Jangan mengubahnya menjadi publik tanpa meninjau seluruh isi `backups/`. Nilai `ADMIN_SESSION_SECRET`, `ADMIN_PIN_VERIFIER`, token Netlify, dan koneksi database tidak disimpan di Git. Simpan atau pulihkan nilai rahasia melalui pengaturan lingkungan Netlify secara terpisah. PIN admin tidak dicatat dalam repositori.

## Status cadangan

Snapshot `2026-11-26` adalah salinan konten saat diekspor, bukan sinkronisasi otomatis. Setelah mengedit situs lewat admin, buat snapshot baru agar GitHub dan Drive kembali sesuai dengan situs aktif.
