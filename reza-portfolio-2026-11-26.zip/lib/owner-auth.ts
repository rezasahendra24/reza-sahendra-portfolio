import { hasValidAdminSession } from "@/lib/admin-session";

export function ownerId(_headers: Pick<Headers, "get">) {
  return "reza-admin";
}

export function ownerDenied() {
  return Response.json({ error: "Halaman ini hanya tersedia untuk pemilik situs." }, {
    status: 403, headers: { "cache-control": "no-store" },
  });
}

export async function ownerApiError(request: Request) {
  const id = ownerId(request.headers);
  if (!id) return ownerDenied();
  if (!await hasValidAdminSession(request.headers.get("cookie"), id)) {
    return Response.json({ error: "Buka halaman admin dan masukkan PIN." }, {
      status: 401, headers: { "cache-control": "no-store" },
    });
  }
  return null;
}

export function sameOriginRequest(request: Request) {
  const origin = request.headers.get("origin");
  return !origin || origin === new URL(request.url).origin;
}
