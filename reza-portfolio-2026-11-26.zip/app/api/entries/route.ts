import { and, asc, desc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { entries } from "@/db/schema";

export async function GET(request: Request) {
  const kind = new URL(request.url).searchParams.get("kind");
  if (kind && kind !== "project" && kind !== "post") {
    return Response.json({ error: "Jenis konten tidak dikenal." }, { status: 400 });
  }
  try {
    const filters = [eq(entries.status, "published")];
    if (kind === "project" || kind === "post") filters.push(eq(entries.kind, kind));
    const query = getDb().select().from(entries).where(and(...filters));
    const rows = kind === "project"
      ? await query.orderBy(asc(entries.sortOrder), desc(entries.updatedAt)).limit(30)
      : await query.orderBy(desc(entries.updatedAt)).limit(30);
    return Response.json({ entries: rows }, { headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "Konten belum tersedia." }, { status: 503 });
  }
}
