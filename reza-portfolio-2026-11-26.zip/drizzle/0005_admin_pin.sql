CREATE TABLE `admin_pin` (
	`id` integer PRIMARY KEY NOT NULL,
	`attempt_count` integer DEFAULT 0 NOT NULL,
	`attempt_sequence` integer DEFAULT 0 NOT NULL,
	`window_ends_at` integer DEFAULT 0 NOT NULL,
	CONSTRAINT "admin_pin_singleton" CHECK("admin_pin"."id" = 1)
);
