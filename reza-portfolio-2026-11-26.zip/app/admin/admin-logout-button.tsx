"use client";

import { useState } from "react";

export default function AdminLogoutButton() {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  async function logout() {
    setSubmitting(true);
    setError("");
    const response = await fetch("/api/admin/logout", { method: "POST", cache: "no-store" }).catch(() => null);
    if (response?.ok) {
      window.location.reload();
      return;
    }
    setError("Gagal mengunci ruang admin. Coba lagi.");
    setSubmitting(false);
  }
  return (
    <>
      <button className="admin-logout" type="button" onClick={logout} disabled={submitting}>
        {submitting ? "Mengunci…" : "Kunci admin"}
      </button>
      {error && <span className="admin-login-error" role="alert">{error}</span>}
    </>
  );
}
