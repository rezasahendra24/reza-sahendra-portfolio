import { readFileSync, writeFileSync } from "node:fs";
import { defaultSiteContent } from "../lib/site-content-defaults.ts";

const seed = readFileSync(new URL("../netlify/database/migrations/20261122000200_seed.sql", import.meta.url), "utf8");
const line = seed.split(/\r?\n/).find((item) => item.startsWith("INSERT INTO site_settings") && item.includes("VALUES ('content'"));
if (!line) throw new Error("Seeded site content was not found.");

const startMarker = "VALUES ('content', '";
const endMarker = ',"… [truncated for model]';
const start = line.indexOf(startMarker) + startMarker.length;
const end = line.indexOf(endMarker, start);
if (end < 0) throw new Error("Expected truncated seed marker was not found.");

const savedPrefix = line.slice(start, end).replaceAll("''", "'");
const saved = JSON.parse(savedPrefix + "}}");
const content = structuredClone(defaultSiteContent);
for (const [section, values] of Object.entries(saved)) {
  if (section in content && values && typeof values === "object" && !Array.isArray(values)) {
    Object.assign(content[section], values);
  }
}

const json = JSON.stringify(content);
JSON.parse(json);
const escaped = json.replaceAll("'", "''");
const sql = `INSERT INTO site_settings (key, value, updated_at) VALUES ('content', '${escaped}', CURRENT_TIMESTAMP::text) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = EXCLUDED.updated_at;\n`;
writeFileSync(new URL("../netlify/database/migrations/20261122000300_repair_content.sql", import.meta.url), sql);
console.log(`Created valid content migration (${json.length} characters).`);
