import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { entries, siteSettings } from "@/db/schema";
import { defaultSiteContent, normalizeSiteContent } from "@/lib/site-content-defaults";
import { ownerApiError, sameOriginRequest } from "@/lib/owner-auth";

const initialProjects = [
  {
    kind: "project" as const,
    title: "Ojek Bengkalis Simpang",
    slug: "ojek-bengkalis-simpang",
    summary: "Mengelola operasional layanan Ojek Bengkalis Simpang.",
    content: "Menjalankan peran Direktur Operasional di Ojek Bengkalis Simpang.",
    category: "Direktur Operasional",
    externalUrl: "https://ojek-bengkalis-simpang.netlify.app/",
    status: "published" as const,
  },
  {
    kind: "project" as const,
    title: "WeSolve Tech",
    slug: "wesolvetech",
    summary: "Memimpin perusahaan teknologi sebagai Direktur Utama.",
    content: "Menjalankan peran Direktur Utama di WeSolve Tech.",
    category: "Direktur Utama",
    externalUrl: "https://wesolvetech.pages.dev/",
    status: "published" as const,
  },
];

export async function POST(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  const denied = await ownerApiError(request);
  if (denied) return denied;
  const db = getDb();
  const [marker] = await db.select().from(siteSettings).where(eq(siteSettings.key, "projects_bootstrapped")).limit(1);
  if (marker) return Response.json({ ok: true, imported: 0, initialized: true });
  const existing = await db.select({ id: entries.id }).from(entries).where(eq(entries.kind, "project")).limit(1);
  const now = new Date().toISOString();
  const [contentRow] = await db.select().from(siteSettings).where(eq(siteSettings.key, "content")).limit(1);
  const content = normalizeSiteContent(contentRow ? JSON.parse(contentRow.value) : defaultSiteContent);
  content.works.showDefaultProjects = false;
  await db.transaction(async (tx) => {
    if (!existing.length) await tx.insert(entries).values(initialProjects.map((entry) => ({ ...entry, updatedAt: now })));
    await tx.insert(siteSettings).values({ key: "content", value: JSON.stringify(content), updatedAt: now }).onConflictDoUpdate({ target: siteSettings.key, set: { value: JSON.stringify(content), updatedAt: now } });
    await tx.insert(siteSettings).values({ key: "projects_bootstrapped", value: "1", updatedAt: now }).onConflictDoNothing();
  });
  return Response.json({ ok: true, imported: existing.length ? 0 : initialProjects.length, initialized: true }, { status: 201 });
}
