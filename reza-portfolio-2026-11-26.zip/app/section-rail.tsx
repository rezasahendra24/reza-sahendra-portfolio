"use client";

import { ArrowUp, BriefcaseBusiness, House, Images, Mail, NotebookPen, UserRound, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";

const sections = [
  { id: "beranda", label: "Beranda", icon: House },
  { id: "tentang", label: "Tentang saya", icon: UserRound },
  { id: "karya", label: "Karya pilihan", icon: BriefcaseBusiness },
  { id: "galeri", label: "Galeri foto", icon: Images },
  { id: "catatan", label: "Catatan", icon: NotebookPen },
  { id: "kontak", label: "Kontak", icon: Mail },
] as const;

function focusSection(id: string) {
  const section = document.getElementById(id);
  if (!section) return;
  if (!section.hasAttribute("tabindex")) section.tabIndex = -1;
  section.focus({ preventScroll: true });
}

export default function SectionRail({ labels, panelTitle }: { labels: Record<string, string>; panelTitle: string }) {
  const [visible, setVisible] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("beranda");
  const railRef = useRef<HTMLElement>(null);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const isVisible = visible || open;

  useEffect(() => {
    const updateVisibility = () => {
      setVisible(window.scrollY > 120);
      setShowBackToTop(window.scrollY > 400);
    };
    updateVisibility();
    window.addEventListener("scroll", updateVisibility, { passive: true });

    const observer = new IntersectionObserver((entries) => {
      const current = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (current) setActive(current.target.id);
    }, { rootMargin: "-30% 0px -55% 0px", threshold: [0, 0.2, 0.5] });
    sections.forEach(({ id }) => {
      const section = document.getElementById(id);
      if (section) observer.observe(section);
    });

    return () => {
      window.removeEventListener("scroll", updateVisibility);
      observer.disconnect();
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        setOpen(false);
        toggleRef.current?.focus({ preventScroll: true });
      }
    };
    const closeOnOutsideClick = (event: PointerEvent) => {
      if (event.target instanceof Node && !railRef.current?.contains(event.target)) setOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    document.addEventListener("pointerdown", closeOnOutsideClick);
    return () => {
      window.removeEventListener("keydown", closeOnEscape);
      document.removeEventListener("pointerdown", closeOnOutsideClick);
    };
  }, [open]);

  return (
    <aside className={`floating-nav ${isVisible ? "is-visible" : ""} ${open ? "is-open" : ""}`} ref={railRef} aria-label="Navigasi halaman" aria-hidden={!isVisible} inert={!isVisible} onBlur={(event) => {
      if (!event.currentTarget.contains(event.relatedTarget)) setOpen(false);
    }}>
      <button className="floating-nav-toggle" ref={toggleRef} type="button" tabIndex={isVisible ? 0 : -1} aria-expanded={open} aria-controls="floating-nav-panel" aria-label={open ? "Tutup navigasi" : "Buka navigasi halaman"} onClick={() => setOpen((value) => !value)}>
        <span className="floating-nav-toggle-icon" aria-hidden="true"><i/><i/><i/></span>
      </button>
      <button className="back-to-top-button" type="button" hidden={!showBackToTop} tabIndex={isVisible && showBackToTop ? 0 : -1} aria-label="Kembali ke atas halaman" onClick={() => {
        setOpen(false);
        window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth" });
        focusSection("beranda");
      }}><ArrowUp size={20} strokeWidth={2} aria-hidden="true" /></button>
      <nav className="floating-nav-panel" id="floating-nav-panel" aria-label="Bagian halaman" aria-hidden={!open} inert={!open}>
        <div className="floating-nav-heading"><span>{panelTitle}</span><button type="button" aria-label="Tutup navigasi" onClick={() => { setOpen(false); toggleRef.current?.focus({ preventScroll: true }); }}><X size={16} strokeWidth={1.8} aria-hidden="true" /></button></div>
        {sections.map(({ id, label, icon: Icon }) => (
          <a href={id === "catatan" ? "/catatan" : `#${id}`} key={id} className={active === id ? "is-active" : ""} aria-current={active === id ? "location" : undefined} onClick={() => { setOpen(false); if (id !== "catatan") focusSection(id); }}>
            <Icon aria-hidden="true" strokeWidth={1.8}/><span>{labels[id] || label}</span>
          </a>
        ))}
      </nav>
    </aside>
  );
}
