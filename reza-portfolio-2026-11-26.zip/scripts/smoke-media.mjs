const origin = "https://rezasahendra.netlify.app";
const pin = process.env.REZA_SMOKE_PIN;
if (!pin) throw new Error("Set REZA_SMOKE_PIN before running this check.");

const login = await fetch(`${origin}/api/admin/pin`, {
  method: "POST",
  headers: { origin, "content-type": "application/json" },
  body: JSON.stringify({ pin }),
});
if (!login.ok) throw new Error(`Login failed: ${login.status}`);
const cookie = login.headers.get("set-cookie")?.split(";")[0];
if (!cookie) throw new Error("Admin session cookie was not set.");

const bytes = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/nXcAAAAASUVORK5CYII=", "base64");
const form = new FormData();
form.append("kind", "image");
form.append("file", new Blob([bytes], { type: "image/png" }), "smoke-test.png");
const upload = await fetch(`${origin}/api/admin/media`, { method: "POST", headers: { origin, cookie }, body: form });
if (!upload.ok) throw new Error(`Upload failed: ${upload.status} ${await upload.text()}`);
const { src } = await upload.json();
try {
  const media = await fetch(`${origin}${src}`);
  if (!media.ok || media.headers.get("content-type") !== "image/png") throw new Error(`Media delivery failed: ${media.status}`);
  console.log(`Login ${login.status}; upload ${upload.status}; media ${media.status}.`);
} finally {
  const remove = await fetch(`${origin}/api/admin/media`, {
    method: "DELETE", headers: { origin, cookie, "content-type": "application/json" }, body: JSON.stringify({ src }),
  });
  console.log(`Cleanup ${remove.status}.`);
}
