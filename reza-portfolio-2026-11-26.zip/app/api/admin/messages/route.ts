import { desc } from "drizzle-orm";
import { getDb } from "@/db";
import { messages } from "@/db/schema";
import { ownerApiError } from "@/lib/owner-auth";

export async function GET(request: Request) {
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const rows = await getDb().select().from(messages).orderBy(desc(messages.createdAt)).limit(100);
    return Response.json({ messages: rows }, { headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "Kotak pesan belum tersedia." }, { status: 503 });
  }
}
