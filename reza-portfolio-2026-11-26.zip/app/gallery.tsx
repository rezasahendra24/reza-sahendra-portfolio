"use client";

import Image from "next/image";
import { Maximize2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { GalleryPhoto, SiteContent } from "@/lib/site-content-defaults";

export default function Gallery({ photos, labels }: { photos: GalleryPhoto[]; labels: SiteContent["gallery"] }) {
  const [active, setActive] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const lightboxRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  // Content can be edited while the gallery is mounted. Keep its selection valid.
  if (active !== null && active >= photos.length) {
    setActive(photos.length > 0 ? photos.length - 1 : null);
  }

  const photo = active === null ? undefined : photos[active];
  const isOpen = photo !== undefined;

  const movePhoto = (direction: number) => {
    if (photos.length < 2) return;
    setActive((current) => current === null ? null : (current + direction + photos.length) % photos.length);
  };

  useEffect(() => {
    if (!isOpen) return;
    const previousFocus = triggerRef.current ?? document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus({ preventScroll: true });

    const keepFocusInside = (event: FocusEvent) => {
      if (event.target instanceof Node && !lightboxRef.current?.contains(event.target)) {
        closeRef.current?.focus({ preventScroll: true });
      }
    };
    document.addEventListener("focusin", keepFocusInside);

    return () => {
      document.removeEventListener("focusin", keepFocusInside);
      document.body.style.overflow = previousOverflow;
      if (previousFocus instanceof HTMLElement && previousFocus.isConnected) {
        previousFocus.focus({ preventScroll: true });
      }
    };
  }, [isOpen]);

  return <>
    <div className="gallery-grid">
      {photos.map((photo, index) => <button className={`gallery-tile gallery-tile-${index + 1}`} key={photo.src} type="button" onClick={(event) => { triggerRef.current = event.currentTarget; setActive(index); }} aria-label={`${labels.openPhotoLabel}: ${photo.caption}`}>
        <span className="gallery-frame">
          <Image src={photo.src} alt={photo.alt} fill sizes="(max-width: 650px) 100vw, (max-width: 950px) 50vw, 25vw" quality={78} unoptimized={photo.src.startsWith("/api/media/")} />
          <span className="gallery-zoom" aria-hidden="true"><Maximize2 size={16} strokeWidth={1.6} /></span>
        </span>
        <span className="gallery-caption"><span className="gallery-caption-text">{photo.caption}</span></span>
      </button>)}
    </div>
    {photo && <div className="lightbox" ref={lightboxRef} role="dialog" aria-modal="true" aria-labelledby="lightbox-caption" onMouseDown={(event) => { if (event.target === event.currentTarget) setActive(null); }} onKeyDown={(event) => {
      if (event.key === "Escape" || event.key === "ArrowRight" || event.key === "ArrowLeft") {
        event.preventDefault();
        event.stopPropagation();
        if (event.key === "Escape") setActive(null);
        else movePhoto(event.key === "ArrowRight" ? 1 : -1);
      }

      if (event.key === "Tab") {
        const buttons = lightboxRef.current?.querySelectorAll<HTMLButtonElement>("button:not(:disabled)");
        const first = buttons?.[0];
        const last = buttons?.[buttons.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    }}>
      <button className="lightbox-close" ref={closeRef} type="button" onClick={() => setActive(null)} aria-label={labels.closeLabel}>{labels.closeLabel}</button>
      <button className="lightbox-previous" type="button" onClick={() => movePhoto(-1)} disabled={photos.length < 2} aria-label={labels.previousLabel}>{labels.previousLabel}</button>
      <figure className="lightbox-figure"><Image src={photo.src} alt={photo.alt} width={photo.width} height={photo.height} sizes="90vw" quality={88} priority unoptimized={photo.src.startsWith("/api/media/")}/><figcaption id="lightbox-caption" aria-live="polite">{photo.caption}</figcaption></figure>
      <button className="lightbox-next" type="button" onClick={() => movePhoto(1)} disabled={photos.length < 2} aria-label={labels.nextLabel}>{labels.nextLabel}</button>
    </div>}
  </>;
}
