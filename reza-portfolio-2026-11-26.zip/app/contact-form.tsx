"use client";

import { FormEvent, useState } from "react";
import type { SiteContent } from "@/lib/site-content-defaults";

export default function ContactForm({ settings }: { settings: SiteContent["contact"] }) {
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState("sending");
    const form = event.currentTarget;
    const values = Object.fromEntries(new FormData(form).entries());
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!response.ok) throw new Error("Message could not be saved");
      form.reset();
      setState("sent");
    } catch {
      setState("error");
    }
  }

  return (
    <form className="message-form" onSubmit={submit}>
      <label>{settings.nameLabel}<input name="name" required maxLength={100} autoComplete="name" placeholder={settings.namePlaceholder}/></label>
      <label>{settings.emailLabel}<input name="email" type="email" required maxLength={200} autoComplete="email" placeholder={settings.emailPlaceholder}/></label>
      <label className="message-field">{settings.messageLabel}<textarea name="message" required minLength={5} maxLength={4000} rows={4} placeholder={settings.messagePlaceholder}/></label>
      <label className="honeypot" aria-hidden="true">Website<input name="website" tabIndex={-1} autoComplete="off"/></label>
      <button className="button button-dark" type="submit" disabled={state === "sending"}>{state === "sending" ? settings.sendingLabel : settings.submitLabel}</button>
      <p className={`form-status ${state}`} aria-live="polite">{state === "sent" ? settings.sentMessage : state === "error" ? settings.errorMessage : ""}</p>
    </form>
  );
}
