import { getStore } from "@netlify/blobs";

export async function GET(request: Request, context: { params: Promise<{ key: string }> }) {
  const { key } = await context.params;
  if (!/^[a-f0-9-]+\.(?:jpe?g|png|webp|mp3)$/i.test(key)) return new Response("Media tidak ditemukan.", { status: 404 });
  const object = await getStore("media").getWithMetadata(key, { type: "arrayBuffer" });
  if (!object?.data) return new Response("Media tidak ditemukan.", { status: 404 });
  const data = object.data;
  const size = data.byteLength;
  const headers = new Headers({
    "content-type": typeof object.metadata?.contentType === "string" ? object.metadata.contentType : key.endsWith(".mp3") ? "audio/mpeg" : "application/octet-stream",
    "cache-control": "public, max-age=31536000, immutable",
    "x-content-type-options": "nosniff",
    "accept-ranges": "bytes",
  });
  if (object.etag) headers.set("etag", object.etag);
  const range = request.headers.get("range")?.match(/^bytes=(\d+)-(\d*)$/);
  if (range) {
    const start = Number(range[1]);
    const end = range[2] ? Number(range[2]) : size - 1;
    if (start >= size || end < start || end >= size) return new Response(null, { status: 416, headers: { "content-range": `bytes */${size}` } });
    const chunk = data.slice(start, end + 1);
    headers.set("content-range", `bytes ${start}-${end}/${size}`);
    headers.set("content-length", String(chunk.byteLength));
    return new Response(chunk, { status: 206, headers });
  }
  headers.set("content-length", String(size));
  return new Response(data, { headers });
}
