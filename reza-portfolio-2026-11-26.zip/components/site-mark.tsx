import Image from "next/image";

type SiteMarkProps = {
  brandMark: string;
  logoImage: string;
  logoImageAlt: string;
};

export default function SiteMark({ brandMark, logoImage, logoImageAlt }: SiteMarkProps) {
  return (
    <span className={logoImage ? "mark has-logo" : "mark"}>
      {logoImage ? (
        <Image
          src={logoImage}
          alt={logoImageAlt}
          width={32}
          height={32}
          unoptimized={logoImage.startsWith("/api/media/")}
        />
      ) : brandMark}
    </span>
  );
}
