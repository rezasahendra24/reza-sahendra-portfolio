/* eslint-disable @next/next/no-html-link-for-pages -- Native navigation avoids the current vinext Link click error. */
import { and, eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getDb } from "@/db";
import { entries } from "@/db/schema";
import { getSiteContent } from "@/lib/site-content";
import SiteMark from "@/components/site-mark";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  try {
    const [post] = await getDb().select({ title: entries.title, summary: entries.summary }).from(entries)
      .where(and(eq(entries.slug, slug), eq(entries.kind, "post"), eq(entries.status, "published"))).limit(1);
    if (post) return {
      title: `${post.title} | Reza Sahendra`,
      description: post.summary,
      alternates: { canonical: `/jurnal/${encodeURIComponent(slug)}` },
      openGraph: { type: "article", title: post.title, description: post.summary },
    };
  } catch { /* Page rendering handles unavailable content. */ }
  return { title: "Catatan | Reza Sahendra", robots: { index: false } };
}

export default async function JournalPost({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  let post;
  try {
    [post] = await getDb().select().from(entries).where(and(
      eq(entries.slug, slug), eq(entries.kind, "post"), eq(entries.status, "published"),
    )).limit(1);
  } catch { notFound(); }
  if (!post) notFound();
  const content = await getSiteContent();

  return <main className="article-page"><header className="topbar"><a className="wordmark" href="/"><SiteMark brandMark={content.general.brandMark} logoImage={content.general.logoImage} logoImageAlt={content.general.logoImageAlt}/><span>{content.general.brandName}</span></a><a className="contact-link" href="/catatan">{content.blog.backLabel}</a></header><article className="article-body"><p className="eyebrow">{post.category || content.blog.categoryFallback} · {new Date(post.updatedAt).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}</p><h1>{post.title}</h1><p className="article-summary">{post.summary}</p><div className="article-copy">{post.content}</div></article><footer className="footer article-footer"><a href="/">{content.general.brandName}</a><a href="/catatan">{content.blog.allPostsLabel}</a></footer></main>;
}
