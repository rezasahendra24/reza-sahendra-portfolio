/* eslint-disable @next/next/no-html-link-for-pages -- Native navigation avoids the current vinext Link click error. */
import { and, desc, eq } from "drizzle-orm";
import { BookOpen } from "lucide-react";
import type { Metadata } from "next";
import { getDb } from "@/db";
import { entries } from "@/db/schema";
import { getSiteContent } from "@/lib/site-content";
import SiteMark from "@/components/site-mark";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Catatan | Reza Sahendra",
  description: "Tulisan dan catatan pribadi Reza Sahendra.",
  alternates: { canonical: "/catatan" },
};

export default async function CatatanPage() {
  const [content, posts] = await Promise.all([
    getSiteContent(),
    getDb().select().from(entries)
      .where(and(eq(entries.kind, "post"), eq(entries.status, "published")))
      .orderBy(desc(entries.updatedAt)).limit(100).catch(() => []),
  ]);

  return <div className="site-home journal-index">
    <a className="skip-link" href="#main-content">Langsung ke konten</a>
    <header className="topbar">
      <a className="wordmark" href="/"><SiteMark brandMark={content.general.brandMark} logoImage={content.general.logoImage} logoImageAlt={content.general.logoImageAlt}/><span>{content.general.brandName}</span></a>
      <nav aria-label="Navigasi utama"><a href="/">{content.home.navLabel}</a><a href="/#tentang">{content.about.navLabel}</a><a href="/#karya">{content.works.navLabel}</a><a href="/#galeri">{content.gallery.navLabel}</a></nav>
      <a className="contact-link" href="/#kontak">{content.navigation.contactCta}</a>
    </header>
    <main id="main-content">
      <section className="journal-section">
        <div className="wrap journal-wrap">
          <div className="section-head journal-head"><div><p className="section-kicker">{content.blog.kicker}</p><h1>{content.blog.titleFirst}<br/>{content.blog.titleSecond}</h1></div><p className="section-aside">{content.blog.description}</p></div>
          {posts.length ? <div className="journal-list">{posts.map(post => <a className="journal-item" href={`/jurnal/${post.slug}`} key={post.id}>
            <span className="journal-date">{post.category || content.blog.categoryFallback}</span>
            <div><h3>{post.title}</h3><p>{post.summary}</p></div>
            <time className="journal-type" dateTime={post.updatedAt}>{new Date(post.updatedAt).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" })}</time>
            <BookOpen className="journal-plus" size={22} strokeWidth={1.3} aria-hidden="true"/>
          </a>)}</div> : <div className="empty-state empty-state-dark"><BookOpen size={30} strokeWidth={1.3} aria-hidden="true"/><div><h3>{content.blog.emptyTitle}</h3><p>{content.blog.emptyDescription}</p></div></div>}
        </div>
      </section>
    </main>
    <footer className="footer wrap"><a className="wordmark" href="/"><SiteMark brandMark={content.general.brandMark} logoImage={content.general.logoImage} logoImageAlt={content.general.logoImageAlt}/><span>{content.general.brandName}</span></a><span className="footer-note">{content.general.footerNote}</span><div className="footer-links"><a href="/">{content.home.navLabel}</a><a href="/admin">{content.general.adminLinkLabel}</a></div></footer>
  </div>;
}
