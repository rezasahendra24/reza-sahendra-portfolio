/* eslint-disable @next/next/no-html-link-for-pages -- Native navigation avoids the current vinext Link click error. */
"use client";

import { FormEvent, useState } from "react";

export default function AdminPinForm() {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting) return;
    if (!/^[0-9]{6}$/.test(pin)) {
      setError("Masukkan PIN yang terdiri dari 6 angka.");
      return;
    }

    setError("");
    setSubmitting(true);
    try {
      const response = await fetch("/api/admin/pin", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ pin }),
        cache: "no-store",
      });
      if (response.ok) {
        window.location.reload();
        return;
      }

      const messages: Record<number, string> = {
        400: "Periksa kembali PIN yang Anda masukkan.",
        401: "PIN salah. Coba lagi.",
        403: "Permintaan ditolak. Muat ulang halaman dan coba lagi.",
        429: "Terlalu banyak percobaan. Tunggu beberapa saat sebelum mencoba lagi.",
      };
      setError(messages[response.status] ?? "Permintaan belum berhasil. Coba lagi sebentar.");
    } catch {
      setError("Gagal terhubung ke situs. Periksa koneksi Anda lalu coba lagi.");
    }
    setSubmitting(false);
  }

  return (
    <main className="admin-shell">
      <header className="admin-topbar">
        <a className="wordmark" href="/"><span className="mark">R.</span><span>REZA SAHENDRA</span></a>
        <a className="admin-user" href="/">Lihat situs</a>
      </header>
      <section className="admin-login-card">
        <p className="eyebrow">AREA ADMIN</p>
        <h1>Buka ruang admin.</h1>
        <p>Masukkan PIN 6 angka Anda untuk membuka editor.</p>
        <form className="admin-login-form" onSubmit={submit}>
          <label>
            PIN
            <input type="password" inputMode="numeric" autoComplete="current-password"
              pattern="[0-9]{6}" minLength={6} maxLength={6} required value={pin}
              onChange={(event) => setPin(event.target.value)} />
          </label>
          {error && <p className="admin-login-error" role="alert">{error}</p>}
          <button className="button button-dark" type="submit" disabled={submitting}>
            {submitting ? "Memproses…" : "Buka admin"}
          </button>
        </form>
      </section>
    </main>
  );
}
