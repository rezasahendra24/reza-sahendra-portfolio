import { sql } from "drizzle-orm";
import { check, integer, pgTable, serial, text } from "drizzle-orm/pg-core";

export const entries = pgTable("entries", {
  id: serial("id").primaryKey(),
  kind: text("kind", { enum: ["project", "post"] }).notNull(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  summary: text("summary").notNull().default(""),
  content: text("content").notNull().default(""),
  category: text("category").notNull().default(""),
  externalUrl: text("external_url"),
  coverImage: text("cover_image"),
  audioSrc: text("audio_src"),
  status: text("status", { enum: ["draft", "published"] }).notNull().default("draft"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  message: text("message").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const siteSettings = pgTable("site_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const adminPin = pgTable("admin_pin", {
  id: integer("id").primaryKey(),
  attemptCount: integer("attempt_count").notNull().default(0),
  attemptSequence: integer("attempt_sequence").notNull().default(0),
  windowEndsAt: integer("window_ends_at").notNull().default(0),
}, (table) => [check("admin_pin_singleton", sql`${table.id} = 1`)]);

export const galleryPhotos = pgTable("gallery_photos", {
  id: serial("id").primaryKey(),
  src: text("src").notNull(),
  alt: text("alt").notNull().default(""),
  caption: text("caption").notNull().default(""),
  width: integer("width").notNull().default(1200),
  height: integer("height").notNull().default(900),
  sortOrder: integer("sort_order").notNull().default(0),
});
