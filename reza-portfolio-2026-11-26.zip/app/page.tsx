import Image from "next/image";
import type { Metadata } from "next";
import { and, asc, desc, eq } from "drizzle-orm";
import { BriefcaseBusiness, Camera, Code2, Globe, MessageCircle, Music2, Sparkles, Users, Video } from "lucide-react";
import { getDb } from "@/db";
import { entries } from "@/db/schema";
import { getGalleryPhotos, getSiteContent } from "@/lib/site-content";
import ContactForm from "./contact-form";
import Gallery from "./gallery";
import SectionRail from "./section-rail";
import SiteMark from "@/components/site-mark";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { alternates: { canonical: "/" } };

async function loadProjects() {
  try {
    return await getDb().select().from(entries)
      .where(and(eq(entries.kind, "project"), eq(entries.status, "published")))
      .orderBy(asc(entries.sortOrder), desc(entries.updatedAt)).limit(100);
  } catch {
    return [];
  }
}

const initialProjects = [
  { id: "start-1", title: "Ojek Bengkalis Simpang", summary: "Mengelola operasional layanan Ojek Bengkalis Simpang.", category: "Direktur Operasional", externalUrl: "https://ojek-bengkalis-simpang.netlify.app/", coverImage: null, audioSrc: null, sortOrder: 0 },
  { id: "start-2", title: "WeSolve Tech", summary: "Memimpin perusahaan teknologi sebagai Direktur Utama.", category: "Direktur Utama", externalUrl: "https://wesolvetech.pages.dev/", coverImage: null, audioSrc: null, sortOrder: 1 },
];

const imageAspects: Record<string, string> = { "1:1": "1 / 1", "4:5": "4 / 5", "3:4": "3 / 4", "16:9": "16 / 9" };

function SocialIcon({ url }: { url: string }) {
  let host = "";
  try { host = new URL(url).hostname.replace(/^www\./, ""); } catch { /* Use the generic website icon. */ }
  const icons = { "instagram.com": Camera, "linkedin.com": BriefcaseBusiness, "facebook.com": Users, "youtube.com": Video, "youtu.be": Video, "wa.me": MessageCircle };
  const Icon = icons[host as keyof typeof icons] || Globe;
  return <Icon size={20} strokeWidth={1.6} aria-hidden="true"/>;
}

export default async function Home() {
  const [savedProjects, content, photos] = await Promise.all([
    loadProjects(), getSiteContent(), getGalleryPhotos(),
  ]);
  const projects = savedProjects.length ? savedProjects : content.works.showDefaultProjects ? initialProjects : [];
  const heroImage = content.home.heroImage || "/images/reza-sahendra.jpg";
  const heroAlt = content.home.heroImage ? content.home.heroImageAlt : `Potret ${content.general.brandName}`;
  const navLabels = {
    beranda: content.home.navLabel, tentang: content.about.navLabel,
    karya: content.works.navLabel, galeri: content.gallery.navLabel,
    catatan: content.blog.navLabel, kontak: content.contact.navLabel,
  };
  const personSchema = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: "Reza Sahendra",
    url: "https://rezasahendra.netlify.app/",
    image: new URL(heroImage, "https://rezasahendra.netlify.app").toString(),
    description: content.general.siteDescription,
    worksFor: { "@type": "Organization", name: "Dinas Pariwisata Kebudayaan Kepemudaan dan Olahraga Kabupaten Bengkalis", url: content.about.agencyUrl },
    sameAs: content.socials.socialLinks.map((link) => link.url),
  };

  return (
    <div className="site-home">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(personSchema).replace(/</g, "\\u003c") }}/>
      <a className="skip-link" href="#main-content">Langsung ke konten</a>
      <SectionRail labels={navLabels} panelTitle={content.navigation.panelTitle}/>
      <header className="topbar">
        <a className="wordmark" href="#beranda">
          <SiteMark brandMark={content.general.brandMark} logoImage={content.general.logoImage} logoImageAlt={content.general.logoImageAlt}/>
          <span>{content.general.brandName}</span>
        </a>
        <nav aria-label="Navigasi utama">
          <a href="#tentang">{content.about.navLabel}</a>
          <a href="#karya">{content.works.navLabel}</a>
          <a href="#galeri">{content.gallery.navLabel}</a>
          <a href="/catatan">{content.blog.navLabel}</a>
        </nav>
        <a className="contact-link" href="#kontak">{content.navigation.contactCta}</a>
      </header>

      <main id="main-content">
        <section className="hero wrap" id="beranda">
          <div className="hero-copy">
            <p className="eyebrow">{content.home.eyebrow}</p>
            <h1>{content.home.titleFirst}<br/><span>{content.home.titleSecond}</span></h1>
            <p className="intro">{content.home.intro}</p>
            <div className="hero-actions">
              <a className="button button-dark" href="#karya">{content.home.primaryCta}</a>
              <a className="text-link" href="#tentang">{content.home.secondaryCta}</a>
            </div>
            <p className="location-note"><Sparkles size={18} strokeWidth={1.5} aria-hidden="true"/>{content.home.note}</p>
          </div>
          <figure className="hero-visual">
            <span className="hero-outline" aria-hidden="true"/>
            <div className="hero-photo-frame" style={{ aspectRatio: imageAspects[content.home.heroAspect] || "4 / 5" }}>
              <Image src={heroImage} alt={heroAlt} fill sizes="(max-width: 760px) 90vw, 40vw" priority unoptimized={heroImage.startsWith("/api/media/")}/>
            </div>
            <figcaption><span>{content.general.brandName}</span><span>{content.home.artCaption}</span></figcaption>
          </figure>
        </section>

        <section className="about-section" id="tentang">
          <div className="wrap about-grid">
            <div className="about-content">
              <p className="section-kicker">{content.about.kicker}</p>
              <h2>{content.about.titleFirst}<br/>{content.about.titleSecond}</h2>
              <p className="about-lead">{content.about.agencyUrl ? <a href={content.about.agencyUrl} target="_blank" rel="noopener noreferrer">{content.about.lead}</a> : content.about.lead}</p>
              <p className="about-body">{content.about.body}</p>
              <a className="underlined-link" href="#kontak">{content.about.linkLabel}</a>
            </div>
            <figure className="about-photo">
              <span className="about-photo-frame" style={{ aspectRatio: imageAspects[content.about.portraitAspect] || "1 / 1" }}>
                <Image src={content.about.portraitSrc || "/images/reza-sahendra.jpg"} alt={`Potret ${content.general.brandName}`} fill sizes="(max-width: 760px) 85vw, 33vw" unoptimized={content.about.portraitSrc.startsWith("/api/media/")}/>
              </span>
              <figcaption>{content.general.brandName}<span>{content.general.profileCaption}</span></figcaption>
            </figure>
          </div>
        </section>

        <section className="work-section wrap" id="karya">
          <div className="section-head">
            <div><p className="section-kicker">{content.works.kicker}</p><h2>{content.works.title}</h2></div>
            <p className="section-aside">{content.works.description}</p>
          </div>
          {projects.length ? (
            <div className="project-grid" data-count={projects.length}>
              {projects.map((project, index) => {
                const musical = Boolean(project.audioSrc) || project.category?.toLowerCase() === "musik";
                const Icon = musical ? Music2 : /tech|digital|web/i.test(project.title) ? Code2 : BriefcaseBusiness;
                const initials = project.title.split(/\s+/).filter(Boolean).slice(0, 3).map(word => word[0]).join("");
                return (
                  <article className={`project-card project-card-${index % 3}`} key={project.id}>
                    <div className={`project-art ${project.coverImage ? "has-cover" : ""}`}>
                      {project.coverImage ? (
                        <Image src={project.coverImage} alt={project.title} fill sizes="(max-width: 760px) 90vw, (max-width: 1024px) 45vw, 33vw" unoptimized={project.coverImage.startsWith("/api/media/")}/>
                      ) : (
                        <div className="project-illustration" aria-hidden="true">
                          <Icon size={60} strokeWidth={1}/>
                          <span className="project-initial">{initials}</span>
                          <span className="project-art-title">{project.title}</span>
                        </div>
                      )}
                    </div>
                    <div className="project-details">
                      <div className="project-meta"><span>{project.category || content.works.cardPrefix}</span></div>
                      <h3>{project.title}</h3><p>{project.summary}</p>
                      {project.audioSrc && <audio className="project-audio" controls preload="metadata" src={project.audioSrc} aria-label={`Putar lagu ${project.title}`}/>}
                      {project.externalUrl && <a className="underlined-link" href={project.externalUrl} target="_blank" rel="noopener noreferrer">{content.works.projectLinkLabel}<span className="sr-only"> — {project.title}</span></a>}
                    </div>
                  </article>
                );
              })}
            </div>
          ) : <div className="empty-state"><BriefcaseBusiness size={30} strokeWidth={1.3} aria-hidden="true"/><div><h3>{content.works.emptyTitle}</h3><p>{content.works.emptyDescription}</p></div></div>}
        </section>

        <section className="gallery-section wrap" id="galeri">
          <div className="section-head">
            <div><p className="section-kicker">{content.gallery.kicker}</p><h2>{content.gallery.title}</h2></div>
            <p className="section-aside">{content.gallery.description}</p>
          </div>
          {photos.length ? <Gallery photos={photos} labels={content.gallery}/> : <div className="empty-state"><Camera size={30} strokeWidth={1.3} aria-hidden="true"/><div><h3>{content.gallery.emptyTitle}</h3><p>{content.gallery.emptyDescription}</p></div></div>}
        </section>

        <section className="contact-section wrap" id="kontak">
          <div className="contact-card">
            <div><p className="section-kicker">{content.contact.kicker}</p><h2>{content.contact.titleFirst}<br/>{content.contact.titleSecond}</h2></div>
            <div className="contact-right">
              <p>{content.contact.description}</p>
              <div className="social-list">
                {content.socials.socialLinks.map(link => (
                  <a href={link.url} key={link.id} target="_blank" rel="noopener noreferrer">
                    <span className="social-icon"><SocialIcon url={link.url}/></span>
                    <span>{link.label}</span>
                    <span className="social-open">{content.socials.openLabel}</span>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </section>
        <section className="message-section wrap">
          <div className="message-intro"><p className="section-kicker">{content.contact.formKicker}</p><h2>{content.contact.formTitleFirst}<br/>{content.contact.formTitleSecond}</h2><p>{content.contact.formDescription}</p></div>
          <ContactForm settings={content.contact}/>
        </section>
      </main>
      <footer className="footer wrap">
        <a className="wordmark" href="#beranda"><SiteMark brandMark={content.general.brandMark} logoImage={content.general.logoImage} logoImageAlt={content.general.logoImageAlt}/><span>{content.general.brandName}</span></a>
        <span className="footer-note">{content.general.footerNote}</span>
        <div className="footer-links"><a href="/catatan">{content.blog.navLabel}</a><a href="#galeri">{content.gallery.navLabel}</a><a href="/admin">{content.general.adminLinkLabel}</a></div>
      </footer>
    </div>
  );
}
