import { createAdminSessionCookie } from "@/lib/admin-session";
import { verifyPin } from "@/lib/admin-pin";
import { ownerDenied, ownerId } from "@/lib/owner-auth";

function error(message: string, status: number) {
  return Response.json({ error: message }, { status, headers: { "cache-control": "no-store" } });
}

export async function POST(request: Request) {
  const owner = ownerId(request.headers);
  if (!owner) return ownerDenied();
  if (request.headers.get("origin") !== new URL(request.url).origin) {
    return error("Permintaan tidak valid.", 403);
  }

  const body: unknown = await request.json().catch(() => null);
  if (!body || typeof body !== "object" || !("pin" in body) ||
      typeof body.pin !== "string" || !/^[0-9]{6}$/.test(body.pin)) {
    return error("Masukkan PIN yang terdiri dari 6 angka.", 400);
  }
  try {
    const result = await verifyPin(body.pin);
    if (result === "limited") return error("Terlalu banyak percobaan. Coba lagi dalam 15 menit.", 429);
    if (result !== "ok") return error("PIN belum cocok.", 401);
    return Response.json({ ok: true }, {
      headers: { "cache-control": "no-store", "set-cookie": await createAdminSessionCookie(owner) },
    });
  } catch (cause) {
    console.error("Pemeriksaan PIN admin gagal", cause instanceof Error ? cause.name : "Error");
    return error("PIN belum dapat diperiksa. Coba lagi sebentar.", 503);
  }
}
