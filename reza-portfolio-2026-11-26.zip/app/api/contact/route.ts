import { getDb } from "@/db";
import { messages } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    if (typeof body.website === "string" && body.website.trim()) return Response.json({ ok: true });
    const name = typeof body.name === "string" ? body.name.trim().slice(0, 100) : "";
    const email = typeof body.email === "string" ? body.email.trim().slice(0, 200) : "";
    const message = typeof body.message === "string" ? body.message.trim().slice(0, 4000) : "";
    if (!name || !/^\S+@\S+\.\S+$/.test(email) || message.length < 5) {
      return Response.json({ error: "Lengkapi nama, email, dan pesan yang valid." }, { status: 400 });
    }
    await getDb().insert(messages).values({ name, email, message });
    return Response.json({ ok: true }, { status: 201 });
  } catch {
    return Response.json({ error: "Pesan belum dapat disimpan." }, { status: 503 });
  }
}
