import { and, eq, lt, or, sql } from "drizzle-orm";
import { getDb } from "@/db";
import { adminPin } from "@/db/schema";

const maxAttempts = 5;
const windowSeconds = 15 * 60;
const encoder = new TextEncoder();

export async function verifyPin(pin: string): Promise<"ok" | "wrong" | "limited"> {
  const secret = process.env.ADMIN_SESSION_SECRET;
  const verifier = process.env.ADMIN_PIN_VERIFIER?.match(/^([A-Za-z0-9+/]+=*)\.([A-Za-z0-9+/]{43}=)$/);
  if (!secret || !verifier) throw new Error("Admin PIN verifier is not configured.");

  const db = getDb();
  await db.insert(adminPin).values({ id: 1 }).onConflictDoNothing();
  const now = Math.floor(Date.now() / 1000);
  const newWindow = or(eq(adminPin.attemptCount, 0), lt(adminPin.windowEndsAt, now));
  const [attempt] = await db.update(adminPin).set({
    attemptCount: sql`CASE WHEN ${newWindow} THEN 1 ELSE ${adminPin.attemptCount} + 1 END`,
    windowEndsAt: sql`CASE WHEN ${newWindow} THEN ${now + windowSeconds} ELSE ${adminPin.windowEndsAt} END`,
    attemptSequence: sql`${adminPin.attemptSequence} + 1`,
  }).where(and(eq(adminPin.id, 1), or(newWindow, lt(adminPin.attemptCount, maxAttempts))))
    .returning({ sequence: adminPin.attemptSequence });
  if (!attempt) return "limited";
  if (!/^[0-9]{6}$/.test(pin)) return "wrong";

  const [, salt, digest] = verifier;
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  const signature = Uint8Array.from(atob(digest), (char) => char.charCodeAt(0));
  const message = encoder.encode(`reza-admin-pin:v1:${salt}:${pin}`);
  const matched = await crypto.subtle.verify("HMAC", key, signature, message);
  if (!matched) return "wrong";

  await db.update(adminPin).set({
    attemptCount: sql`LEAST(${adminPin.attemptCount}, ${adminPin.attemptSequence} - ${attempt.sequence})`,
  }).where(eq(adminPin.id, 1));
  return "ok";
}
