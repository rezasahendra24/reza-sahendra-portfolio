import { asc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { galleryPhotos, siteSettings } from "@/db/schema";
import { defaultGalleryPhotos } from "@/lib/site-content-defaults";
import { ownerApiError, sameOriginRequest } from "@/lib/owner-auth";

export async function GET(request: Request) {
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const db = getDb();
    const photos = await db.select().from(galleryPhotos).orderBy(asc(galleryPhotos.sortOrder), asc(galleryPhotos.id));
    const [saved] = photos.length ? [] : await db.select({ key: siteSettings.key }).from(siteSettings).where(eq(siteSettings.key, "gallery_saved")).limit(1);
    return Response.json({ photos: photos.length || saved ? photos : defaultGalleryPhotos }, { headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "Galeri belum dapat dimuat." }, { status: 503 });
  }
}

export async function PUT(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const body = await request.json() as { photos?: unknown };
    if (!Array.isArray(body.photos) || body.photos.length > 30) return Response.json({ error: "Galeri maksimal berisi 30 foto." }, { status: 400 });
    const photos = body.photos.map((item, index) => {
      const photo = item && typeof item === "object" ? item as Record<string, unknown> : {};
      const src = cleanSource(photo.src);
      if (!src) throw new Error("Sumber foto tidak valid.");
      return {
        src,
        alt: typeof photo.alt === "string" ? photo.alt.trim().slice(0, 240) : "",
        caption: typeof photo.caption === "string" ? photo.caption.trim().slice(0, 180) : "",
        width: safeDimension(photo.width, 1200),
        height: safeDimension(photo.height, 900),
        sortOrder: index,
      };
    });
    const db = getDb();
    const now = new Date().toISOString();
    await db.transaction(async (tx) => {
      await tx.delete(galleryPhotos);
      if (photos.length) await tx.insert(galleryPhotos).values(photos);
      await tx.insert(siteSettings).values({ key: "gallery_saved", value: "1", updatedAt: now }).onConflictDoUpdate({ target: siteSettings.key, set: { value: "1", updatedAt: now } });
    });
    return Response.json({ photos, message: "Galeri tersimpan." }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Galeri belum dapat disimpan." }, { status: 400 });
  }
}

function cleanSource(value: unknown) {
  if (typeof value !== "string" || value.length > 1000) return null;
  if (/^\/api\/media\/[a-f0-9-]+\.(?:jpe?g|png|webp)$/i.test(value)) return value;
  if (/^\/media\/[a-f0-9-]+\.(?:jpe?g|png|webp)$/i.test(value)) return value;
  if (/^\/images\/[a-z0-9/_-]+\.(?:jpe?g|png|webp)$/i.test(value) && !value.includes("..")) return value;
  return null;
}

function safeDimension(value: unknown, fallback: number) {
  const n = typeof value === "number" ? Math.round(value) : fallback;
  return Number.isFinite(n) && n > 0 && n <= 16000 ? n : fallback;
}
