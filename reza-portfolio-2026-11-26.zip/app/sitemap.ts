import type { MetadataRoute } from "next";
import { and, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { entries } from "@/db/schema";

export const dynamic = "force-dynamic";
const origin = "https://rezasahendra.netlify.app";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const pages: MetadataRoute.Sitemap = [
    { url: origin + "/", changeFrequency: "monthly", priority: 1 },
    { url: origin + "/catatan", changeFrequency: "weekly", priority: 0.7 },
  ];
  try {
    const posts = await getDb().select({ slug: entries.slug, updatedAt: entries.updatedAt }).from(entries)
      .where(and(eq(entries.kind, "post"), eq(entries.status, "published"))).limit(500);
    for (const post of posts) pages.push({
      url: origin + "/jurnal/" + encodeURIComponent(post.slug),
      lastModified: new Date(post.updatedAt),
      changeFrequency: "monthly",
      priority: 0.6,
    });
  } catch { /* The public pages remain discoverable while the database initializes. */ }
  return pages;
}
