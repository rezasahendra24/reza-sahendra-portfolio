import { clearAdminSessionCookie } from "@/lib/admin-session";
import { sameOriginRequest } from "@/lib/owner-auth";

export async function POST(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  return Response.json({ ok: true }, { headers: { "cache-control": "no-store", "set-cookie": clearAdminSessionCookie() } });
}
