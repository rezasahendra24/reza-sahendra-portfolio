// @ts-nocheck -- Existing admin form uses heterogeneous JSON endpoints; runtime response validation remains in each route.
"use client";

import { FormEvent, ReactNode, useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import { defaultSiteContent, type GalleryPhoto, type SiteContent, type SocialLink } from "@/lib/site-content-defaults";
import PhotoCropper, { cropRatios, type CropRatio } from "./photo-cropper";

type Entry = { id: number; kind: "project" | "post"; title: string; slug: string; summary: string; content: string; category: string; externalUrl: string | null; coverImage: string | null; audioSrc: string | null; status: "draft" | "published"; sortOrder: number; updatedAt: string };
type Message = { id: number; name: string; email: string; message: string; createdAt: string };
type PageKey = "beranda" | "tentang" | "karya" | "galeri" | "catatan" | "kontak";
type Photo = GalleryPhoto & { id?: number };
type CropJob = { target: "hero" | "portrait" | "gallery-add" | "gallery-replace"; file: File; index?: number };
type EntryForm = { kind: Entry["kind"]; title: string; slug: string; summary: string; content: string; category: string; externalUrl: string; coverImage: string; audioSrc: string; status: Entry["status"] };

const pages: { id: PageKey; label: string }[] = [
  { id: "beranda", label: "Beranda" }, { id: "tentang", label: "Tentang" },
  { id: "karya", label: "Karya" }, { id: "galeri", label: "Galeri" },
  { id: "catatan", label: "Catatan / Blog" }, { id: "kontak", label: "Kontak" },
];
const blankEntry = (kind: Entry["kind"]): EntryForm => ({ kind, title: "", slug: "", summary: "", content: "", category: "", externalUrl: "", coverImage: "", audioSrc: "", status: "draft" });
const validCropRatio = (value: string, fallback: CropRatio): CropRatio => value in cropRatios ? value as CropRatio : fallback;

function TextField({ label, value, onChange, type = "text", maxLength = 4000, placeholder }: { label: string; value: string; onChange: (value: string) => void; type?: string; maxLength?: number; placeholder?: string }) {
  return <label>{label}<input type={type} maxLength={maxLength} value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)}/></label>;
}

function TextAreaField({ label, value, onChange, rows = 4, maxLength = 4000 }: { label: string; value: string; onChange: (value: string) => void; rows?: number; maxLength?: number }) {
  return <label>{label}<textarea rows={rows} maxLength={maxLength} value={value} onChange={(event) => onChange(event.target.value)}/></label>;
}

export default function AdminPanel() {
  const [page, setPage] = useState<PageKey>("beranda");
  const [content, setContent] = useState<SiteContent>(defaultSiteContent);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [items, setItems] = useState<Entry[]>([]);
  const [inbox, setInbox] = useState<Message[]>([]);
  const [form, setForm] = useState<EntryForm>(blankEntry("project"));
  const [editId, setEditId] = useState<number | null>(null);
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [ordering, setOrdering] = useState(false);
  const [uploading, setUploading] = useState("");
  const [cropJobs, setCropJobs] = useState<CropJob[]>([]);
  const savedPhotos = useRef<string[]>([]);
  const savedPortrait = useRef(defaultSiteContent.about.portraitSrc);
  const savedHeroImage = useRef(defaultSiteContent.home.heroImage);
  const savedLogoImage = useRef(defaultSiteContent.general.logoImage);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const [entriesResponse, messagesResponse, settingsResponse, galleryResponse] = await Promise.all([
        fetch("/api/admin/entries", { cache: "no-store" }),
        fetch("/api/admin/messages", { cache: "no-store" }),
        fetch("/api/admin/site-content", { cache: "no-store" }),
        fetch("/api/admin/gallery", { cache: "no-store" }),
      ]);
      let [entriesData, messagesData, settingsData, galleryData] = await Promise.all([
        entriesResponse.json(), messagesResponse.json(), settingsResponse.json(), galleryResponse.json(),
      ]);
      if (!entriesResponse.ok) throw new Error(entriesData.error || "Konten belum dapat dimuat.");
      if (!settingsResponse.ok) throw new Error(settingsData.error || "Pengaturan halaman belum dapat dimuat.");
      if (!galleryResponse.ok) throw new Error(galleryData.error || "Galeri belum dapat dimuat.");
      if (!(entriesData.entries || []).some((entry: Entry) => entry.kind === "project")) {
        const bootstrapResponse = await fetch("/api/admin/bootstrap", { method: "POST" });
        if (bootstrapResponse.ok) {
          const bootstrapData = await bootstrapResponse.json();
          if (bootstrapData.imported) {
            const [updatedEntries, updatedSettings] = await Promise.all([
              fetch("/api/admin/entries", { cache: "no-store" }), fetch("/api/admin/site-content", { cache: "no-store" }),
            ]);
            entriesData = await updatedEntries.json();
            settingsData = await updatedSettings.json();
          }
        }
      }
      setItems(entriesData.entries || []);
      setInbox(messagesResponse.ok ? messagesData.messages || [] : []);
      setContent(settingsData.content || defaultSiteContent);
      setPhotos(galleryData.photos || []);
      savedPhotos.current = (galleryData.photos || []).map((photo: Photo) => photo.src);
      savedPortrait.current = (settingsData.content || defaultSiteContent).about.portraitSrc;
      savedHeroImage.current = (settingsData.content || defaultSiteContent).home.heroImage;
      savedLogoImage.current = (settingsData.content || defaultSiteContent).general.logoImage;
      if (!messagesResponse.ok) setNotice(messagesData.error || "Kotak pesan belum tersedia.");
      else setNotice("");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Data belum dapat dimuat.");
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  function update(section: keyof SiteContent, field: string, value: string) {
    setContent((current) => ({ ...current, [section]: { ...current[section], [field]: value } }) as SiteContent);
  }

  function updateSocialLink(index: number, field: "label" | "url", value: string) {
    setContent((current) => ({ ...current, socials: { ...current.socials, socialLinks: current.socials.socialLinks.map((link, linkIndex) => linkIndex === index ? { ...link, [field]: value } : link) } }));
  }

  function addSocialLink() {
    setContent((current) => ({ ...current, socials: { ...current.socials, socialLinks: [...current.socials.socialLinks, { id: `social-${crypto.randomUUID()}`, label: "", url: "" }] } }));
  }

  function removeSocialLink(index: number) {
    setContent((current) => ({ ...current, socials: { ...current.socials, socialLinks: current.socials.socialLinks.filter((_, linkIndex) => linkIndex !== index) } }));
  }

  function moveSocialLink(index: number, direction: -1 | 1) {
    setContent((current) => {
      const socialLinks: SocialLink[] = [...current.socials.socialLinks];
      const target = index + direction;
      if (target < 0 || target >= socialLinks.length) return current;
      [socialLinks[index], socialLinks[target]] = [socialLinks[target], socialLinks[index]];
      return { ...current, socials: { ...current.socials, socialLinks } };
    });
  }

  async function saveContent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true); setNotice("");
    const oldPortrait = savedPortrait.current;
    const oldHeroImage = savedHeroImage.current;
    const oldLogoImage = savedLogoImage.current;
    try {
      const response = await fetch("/api/admin/site-content", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ content }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Perubahan halaman belum dapat disimpan.");
      setContent(data.content);
      savedPortrait.current = data.content.about.portraitSrc;
      savedHeroImage.current = data.content.home.heroImage;
      savedLogoImage.current = data.content.general.logoImage;
      if (oldPortrait !== data.content.about.portraitSrc && !photos.some((photo) => photo.src === oldPortrait) && !items.some((item) => item.coverImage === oldPortrait) && data.content.home.heroImage !== oldPortrait && data.content.general.logoImage !== oldPortrait) await deleteMedia(oldPortrait);
      if (oldHeroImage !== data.content.home.heroImage && !photos.some((photo) => photo.src === oldHeroImage) && !items.some((item) => item.coverImage === oldHeroImage) && data.content.about.portraitSrc !== oldHeroImage && data.content.general.logoImage !== oldHeroImage) await deleteMedia(oldHeroImage);
      if (oldLogoImage !== data.content.general.logoImage && !photos.some((photo) => photo.src === oldLogoImage) && !items.some((item) => item.coverImage === oldLogoImage) && data.content.about.portraitSrc !== oldLogoImage && data.content.home.heroImage !== oldLogoImage) await deleteMedia(oldLogoImage);
      setNotice("Perubahan halaman tersimpan.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Perubahan halaman belum dapat disimpan."); }
    finally { setSaving(false); }
  }

  async function uploadImage(file: File) {
    if (!file.type.startsWith("image/")) throw new Error("Pilih file gambar.");
    const bitmap = await createImageBitmap(file);
    const width = bitmap.width;
    const height = bitmap.height;
    bitmap.close();
    const payload = new FormData(); payload.set("file", file);
    const response = await fetch("/api/admin/media", { method: "POST", body: payload });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Foto belum dapat diunggah.");
    return { src: data.src as string, width, height };
  }

  async function uploadAudio(file: File) {
    if (!file.name.toLowerCase().endsWith(".mp3")) throw new Error("Pilih file berformat MP3.");
    const payload = new FormData(); payload.set("file", file); payload.set("kind", "audio");
    const response = await fetch("/api/admin/media", { method: "POST", body: payload });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "File MP3 belum dapat diunggah.");
    return data.src as string;
  }

  async function deleteMedia(src: string) {
    if (!src.startsWith("/api/media/")) return;
    try { await fetch("/api/admin/media", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ src }) }); } catch { /* best-effort orphan cleanup */ }
  }

  function isMediaReferenced(src: string, excludedEntryId?: number) {
    return photos.some((photo) => photo.src === src)
      || content.about.portraitSrc === src
      || content.home.heroImage === src
      || content.general.logoImage === src
      || items.some((item) => item.id !== excludedEntryId && (item.coverImage === src || item.audioSrc === src));
  }

  function choosePortrait(file?: File) {
    if (file) { setNotice(""); setCropJobs([{ target: "portrait", file }]); }
  }

  function chooseHeroImage(file?: File) {
    if (file) { setNotice(""); setCropJobs([{ target: "hero", file }]); }
  }

  async function recropPhoto(target: CropJob["target"], src: string, index?: number) {
    setUploading("crop-source"); setNotice("");
    try {
      const response = await fetch(src);
      if (!response.ok) throw new Error("Foto belum dapat dibuka untuk crop ulang.");
      const blob = await response.blob();
      if (!blob.type.startsWith("image/")) throw new Error("File foto tidak dikenali.");
      const file = new File([blob], `foto-${target}.jpg`, { type: blob.type });
      setCropJobs([{ target, file, index }]);
    } catch (error) { setNotice(error instanceof Error ? error.message : "Crop ulang belum dapat dibuka."); }
    finally { setUploading(""); }
  }

  const closeCrop = useCallback(() => setCropJobs((current) => current.slice(1)), []);

  async function applyCrop(file: File, ratio: CropRatio) {
    const job = cropJobs[0];
    if (!job) return;
    setUploading(job.target);
    try {
      const uploaded = await uploadImage(file);
      if (job.target === "hero") {
        setContent((current) => ({ ...current, home: { ...current.home, heroImage: uploaded.src, heroAspect: ratio } }));
        setNotice("Foto Beranda siap. Tekan Simpan halaman agar tampil di situs.");
      } else if (job.target === "portrait") {
        setContent((current) => ({ ...current, about: { ...current.about, portraitSrc: uploaded.src, portraitAspect: ratio } }));
        setNotice("Foto Tentang siap. Tekan Simpan halaman agar tampil di situs.");
      } else if (job.target === "gallery-add") {
        const name = job.file.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ");
        setPhotos((current) => [...current, { ...uploaded, alt: `Foto ${name}`, caption: name }]);
        setNotice("Foto galeri siap. Tekan Simpan galeri agar tampil di situs.");
      } else if (job.index !== undefined) {
        setPhotos((current) => current.map((photo, index) => index === job.index ? { ...photo, ...uploaded } : photo));
        setNotice("Foto galeri diganti. Tekan Simpan galeri agar tampil di situs.");
      }
      closeCrop();
    } finally { setUploading(""); }
  }

  async function chooseLogoImage(file?: File) {
    if (!file) return;
    setUploading("logo"); setNotice("");
    try {
      const uploaded = await uploadImage(file);
      update("general", "logoImage", uploaded.src);
      setNotice("Logo diunggah. Tekan Simpan halaman agar logo tampil di situs.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Logo belum dapat diunggah."); }
    finally { setUploading(""); }
  }

  async function chooseProjectCover(file?: File) {
    if (!file) return;
    setUploading("project-cover"); setNotice("");
    try {
      const uploaded = await uploadImage(file);
      setForm((current) => ({ ...current, coverImage: uploaded.src }));
      setNotice("Foto karya diunggah. Simpan karya agar foto tampil pada kartu.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Foto belum dapat diunggah."); }
    finally { setUploading(""); }
  }

  async function chooseProjectAudio(file?: File) {
    if (!file) return;
    setUploading("project-audio"); setNotice("");
    try {
      const src = await uploadAudio(file);
      setForm((current) => ({ ...current, audioSrc: src }));
      setNotice("Lagu MP3 diunggah. Simpan karya agar lagu tampil di situs.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "File MP3 belum dapat diunggah."); }
    finally { setUploading(""); }
  }

  function addPhotos(fileList: FileList | null) {
    if (!fileList?.length) return;
    const files = Array.from(fileList).slice(0, Math.max(0, 30 - photos.length));
    setNotice("");
    setCropJobs(files.map((file) => ({ target: "gallery-add", file })));
  }

  function updatePhoto(index: number, field: "alt" | "caption", value: string) {
    setPhotos((current) => current.map((photo, i) => i === index ? { ...photo, [field]: value } : photo));
  }

  function replacePhoto(index: number, file?: File) {
    if (file) { setNotice(""); setCropJobs([{ target: "gallery-replace", file, index }]); }
  }

  function movePhoto(index: number, direction: -1 | 1) {
    setPhotos((current) => {
      const next = [...current];
      const target = index + direction;
      if (target < 0 || target >= next.length) return current;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  async function saveGallery(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setSaving(true); setNotice("");
    const oldSources = savedPhotos.current;
    try {
      const response = await fetch("/api/admin/gallery", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ photos }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Galeri belum dapat disimpan.");
      setPhotos(data.photos);
      const kept = new Set(photos.map((photo) => photo.src));
      savedPhotos.current = [...kept];
      for (const src of oldSources) if (!kept.has(src) && !isMediaReferenced(src)) await deleteMedia(src);
      setNotice("Galeri foto tersimpan.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Galeri belum dapat disimpan."); }
    finally { setSaving(false); }
  }

  function resetEntry(kind: Entry["kind"]) { setEditId(null); setForm(blankEntry(kind)); }

  async function saveEntry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setNotice("");
    const endpoint = editId ? `/api/admin/entries/${editId}` : "/api/admin/entries";
    const oldEntry = editId ? items.find((item) => item.id === editId) : undefined;
    const oldCover = oldEntry?.coverImage || "";
    const oldAudio = oldEntry?.audioSrc || "";
    try {
      const response = await fetch(endpoint, { method: editId ? "PUT" : "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(form) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Konten belum dapat disimpan.");
      if (oldCover && oldCover !== form.coverImage && !isMediaReferenced(oldCover, editId)) await deleteMedia(oldCover);
      if (oldAudio && oldAudio !== form.audioSrc && !isMediaReferenced(oldAudio, editId)) await deleteMedia(oldAudio);
      setNotice(editId ? "Perubahan konten tersimpan." : "Konten berhasil dibuat.");
      resetEntry(form.kind); await refresh();
    } catch (error) { setNotice(error instanceof Error ? error.message : "Konten belum dapat disimpan."); }
  }

  function editEntry(item: Entry) {
    setPage(item.kind === "project" ? "karya" : "catatan");
    setEditId(item.id);
    setForm({ kind: item.kind, title: item.title, slug: item.slug, summary: item.summary, content: item.content, category: item.category, externalUrl: item.externalUrl || "", coverImage: item.coverImage || "", audioSrc: item.audioSrc || "", status: item.status });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function removeEntry(id: number) {
    if (!window.confirm("Hapus konten ini secara permanen?")) return;
    const response = await fetch(`/api/admin/entries/${id}`, { method: "DELETE" });
    const data = await response.json();
    if (!response.ok) { setNotice(data.error || "Konten belum dapat dihapus."); return; }
    const removed = items.find((item) => item.id === id);
    if (removed?.coverImage && !isMediaReferenced(removed.coverImage, id)) await deleteMedia(removed.coverImage);
    if (removed?.audioSrc && !isMediaReferenced(removed.audioSrc, id)) await deleteMedia(removed.audioSrc);
    if (editId === id) resetEntry(page === "catatan" ? "post" : "project");
    setNotice("Konten dihapus."); await refresh();
  }

  async function importInitialProjects() {
    const response = await fetch("/api/admin/bootstrap", { method: "POST" });
    const data = await response.json();
    if (!response.ok) { setNotice(data.error || "Proyek awal belum dapat dimuat."); return; }
    setNotice(`${data.imported} proyek awal berhasil dimasukkan ke database.`); await refresh();
  }

  async function moveProject(projectId: number, direction: -1 | 1) {
    const ordered = items.filter((item) => item.kind === "project").sort((a, b) => a.sortOrder - b.sortOrder || b.updatedAt.localeCompare(a.updatedAt));
    const currentIndex = ordered.findIndex((item) => item.id === projectId);
    const nextIndex = currentIndex + direction;
    if (currentIndex < 0 || nextIndex < 0 || nextIndex >= ordered.length || ordering) return;
    const reordered = [...ordered];
    [reordered[currentIndex], reordered[nextIndex]] = [reordered[nextIndex], reordered[currentIndex]];
    setOrdering(true); setNotice("");
    try {
      const response = await fetch("/api/admin/entries", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ kind: "project", ids: reordered.map((item) => item.id) }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Urutan karya belum dapat disimpan.");
      await refresh();
      setNotice("Urutan karya tersimpan.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Urutan karya belum dapat disimpan."); }
    finally { setOrdering(false); }
  }

  const field = (section: keyof SiteContent, key: string, label: string, options?: { type?: string; maxLength?: number; placeholder?: string }) => {
    const value = (content[section] as unknown as Record<string, string>)[key] || "";
    return <TextField key={`${section}-${key}`} label={label} value={value} onChange={(next) => update(section, key, next)} {...options}/>;
  };
  const area = (section: keyof SiteContent, key: string, label: string, rows = 4, maxLength = 4000) => {
    const value = (content[section] as unknown as Record<string, string>)[key] || "";
    return <TextAreaField key={`${section}-${key}`} label={label} value={value} onChange={(next) => update(section, key, next)} rows={rows} maxLength={maxLength}/>;
  };
  const settingsForm = (children: ReactNode) => <details className="admin-collapsible admin-settings-collapsible"><summary><span>Editor halaman</span><small>Ubah teks, foto, dan tautan</small></summary><form className="editor-form admin-page-form" onSubmit={saveContent}>{children}<div className="editor-actions"><button className="button button-dark" type="submit" disabled={saving}>{saving ? "Menyimpan…" : "Simpan halaman"}</button></div></form></details>;

  function entriesManager(kind: Entry["kind"]) {
    const relevant = items.filter((item) => item.kind === kind).sort((a, b) => kind === "project" ? a.sortOrder - b.sortOrder || b.updatedAt.localeCompare(a.updatedAt) : b.updatedAt.localeCompare(a.updatedAt));
    const editing = form.kind === kind && editId !== null;
    const showAudioFields = kind === "project" && (form.category.trim().toLowerCase() === "musik" || Boolean(form.audioSrc));
    return <details className="admin-collapsible admin-page-subsection">
      <summary><span>{kind === "project" ? "Kelola karya" : "Daftar tulisan blog"}</span><small>{kind === "project" ? "Tambah, ubah, dan atur urutan" : "Tambah, ubah, atau hapus tulisan"}</small></summary>
      <div className="admin-collapsible-content"><div className="admin-card-head"><div><p className="section-kicker">{kind === "project" ? "DAFTAR KARYA" : "DAFTAR TULISAN"}</p><h2>{kind === "project" ? "Proyek dan pengalaman" : "Tulisan blog"}</h2></div><button className="refresh-button" type="button" onClick={() => void refresh()}>Muat ulang</button></div>
      <form className="editor-form" onSubmit={saveEntry}>
        <div className="form-row"><label>Status<select value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value as Entry["status"] })}><option value="draft">Draf</option><option value="published">Terbitkan</option></select></label><label>Kategori<input list={kind === "project" ? "work-categories" : undefined} maxLength={80} value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })}/></label></div>
        {kind === "project" && <><datalist id="work-categories"><option value="Musik"/><option value="Teknologi"/><option value="Kewirausahaan"/><option value="Pengalaman Profesional"/><option value="Layanan Publik"/><option value="Kreatif"/><option value="Lainnya"/></datalist><p className="admin-page-hint">Pilih kategori dari saran atau tulis kategori sendiri. Untuk lagu, pilih Musik.</p></>}
        <label>Judul<input required maxLength={180} value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })}/></label>
        <label>Slug<input placeholder="dibuat-otomatis-dari-judul" value={form.slug} onChange={(event) => setForm({ ...form, slug: event.target.value })}/></label>
        <label>Ringkasan<input maxLength={500} value={form.summary} onChange={(event) => setForm({ ...form, summary: event.target.value })}/></label>
        <label>Isi<textarea rows={8} maxLength={20000} value={form.content} onChange={(event) => setForm({ ...form, content: event.target.value })}/></label>
        {kind === "project" && <label>Tautan proyek (opsional)<input type="url" placeholder="https://" value={form.externalUrl} onChange={(event) => setForm({ ...form, externalUrl: event.target.value })}/></label>}
        {kind === "project" && <div className="admin-project-cover"><div><h3 className="admin-form-section-title">Foto kartu karya</h3><p>Jika belum diunggah, visual yang sekarang tetap digunakan.</p></div>{form.coverImage ? <Image src={form.coverImage} alt="Pratinjau foto karya" width={180} height={110} unoptimized/> : <div className="admin-cover-empty">Visual saat ini tetap tampil</div>}<div className="editor-actions"><label className="button button-quiet admin-upload-button">{uploading === "project-cover" ? "Mengunggah…" : form.coverImage ? "Ganti foto" : "Pilih foto"}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={Boolean(uploading)} onChange={(event) => { void chooseProjectCover(event.target.files?.[0]); event.currentTarget.value = ""; }}/></label>{form.coverImage && <button className="button button-quiet delete-button" type="button" onClick={() => setForm((current) => ({ ...current, coverImage: "" }))}>Hapus foto</button>}</div></div>}
        {showAudioFields && <div className="admin-audio-upload"><div><h3 className="admin-form-section-title">File lagu MP3</h3><p>Unggah MP3 hingga 20 MB. Lagu akan bisa diputar dari kartu karya.</p></div>{form.audioSrc ? <audio controls preload="metadata" src={form.audioSrc} aria-label="Pratinjau lagu"/> : <div className="admin-audio-empty">Belum ada file lagu</div>}<div className="editor-actions"><label className="button button-quiet admin-upload-button">{uploading === "project-audio" ? "Mengunggah…" : form.audioSrc ? "Ganti lagu" : "Pilih file MP3"}<input type="file" accept=".mp3,audio/mpeg,audio/mp3" disabled={Boolean(uploading)} onChange={(event) => { void chooseProjectAudio(event.target.files?.[0]); event.currentTarget.value = ""; }}/></label>{form.audioSrc && <button className="button button-quiet delete-button" type="button" onClick={() => setForm((current) => ({ ...current, audioSrc: "" }))}>Hapus lagu</button>}</div></div>}
        <div className="editor-actions"><button className="button button-dark" type="submit">{editing ? "Simpan perubahan" : kind === "project" ? "Tambah karya" : "Tambah tulisan"}</button>{editing && <button className="button button-quiet" type="button" onClick={() => resetEntry(kind)}>Batal</button>}</div>
      </form>
      {kind === "project" && !relevant.length && <div className="admin-empty"><p>Belum ada karya di database. Muat karya awal agar bisa diedit di sini.</p><button className="button button-dark" type="button" onClick={() => void importInitialProjects()}>Muat dua proyek awal</button></div>}
      {relevant.length > 0 && <div className="admin-entry-list">{relevant.map((item, index) => <article className="admin-entry" key={item.id}><div><span className="entry-kind">{item.status === "published" ? "TERBIT" : "DRAF"}</span><h3>{item.title}</h3><p>{item.summary}</p></div><div className="entry-actions">{kind === "project" && <><button type="button" aria-label={`Naikkan urutan ${item.title}`} disabled={ordering || index === 0} onClick={() => void moveProject(item.id, -1)}>Naik</button><button type="button" aria-label={`Turunkan urutan ${item.title}`} disabled={ordering || index === relevant.length - 1} onClick={() => void moveProject(item.id, 1)}>Turun</button></>}<button type="button" onClick={() => editEntry(item)}>Edit</button><button className="delete-button" type="button" onClick={() => void removeEntry(item.id)}>Hapus</button></div></article>)}</div>}
      </div>
    </details>;
  }

  const currentTitle = pages.find((item) => item.id === page)?.label || "Beranda";

  return <div className="admin-page-manager">
    <nav className="admin-page-nav" aria-label="Editor halaman situs">{pages.map((item) => <button key={item.id} type="button" className={page === item.id ? "is-active" : ""} aria-pressed={page === item.id} onClick={() => { setPage(item.id); setNotice(""); if (item.id === "karya") resetEntry("project"); if (item.id === "catatan") resetEntry("post"); }}>{item.label}</button>)}</nav>
    <section className="admin-card admin-page-card"><div className="admin-card-head"><div><p className="section-kicker">EDITOR PER HALAMAN</p><h2>{currentTitle}</h2></div><button className="refresh-button" type="button" onClick={() => void refresh()} disabled={loading}>{loading ? "Memuat…" : "Muat ulang"}</button></div>
      {loading && <p className="admin-empty">Memuat pengaturan situs…</p>}
      {!loading && page === "beranda" && settingsForm(<>
        <h3 className="admin-form-section-title">Identitas situs</h3><div className="form-row">{field("general", "brandMark", "Inisial logo", { maxLength: 4 })}{field("general", "brandName", "Nama yang ditampilkan", { maxLength: 80 })}</div>
        <div className="admin-logo-upload"><div>{content.general.logoImage ? <Image src={content.general.logoImage} alt={content.general.logoImageAlt} width={72} height={72} unoptimized/> : <span className="mark">{content.general.brandMark}</span>}<p>{content.general.logoImage ? "Logo kustom dipilih" : "Inisial dipakai sampai logo diunggah"}</p></div><div className="editor-actions"><label className="button button-quiet admin-upload-button">{uploading === "logo" ? "Mengunggah…" : content.general.logoImage ? "Ganti logo" : "Unggah logo"}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={Boolean(uploading)} onChange={(event) => { void chooseLogoImage(event.target.files?.[0]); event.currentTarget.value = ""; }}/></label>{content.general.logoImage && <button className="button button-quiet" type="button" onClick={() => update("general", "logoImage", "")}>Gunakan inisial</button>}</div></div>
        {field("general", "logoImageAlt", "Deskripsi aksesibilitas logo", { maxLength: 120 })}
        <div className="form-row">{field("general", "siteTitle", "Judul browser / SEO", { maxLength: 180 })}{field("general", "siteDescription", "Deskripsi situs", { maxLength: 300 })}</div>
        <div className="form-row">{field("general", "footerNote", "Kalimat footer", { maxLength: 180 })}{field("general", "adminLinkLabel", "Teks tautan admin di footer", { maxLength: 40 })}</div>
        <h3 className="admin-form-section-title">Bagian pembuka</h3><div className="form-row">{field("home", "navLabel", "Label menu Beranda", { maxLength: 40 })}{field("home", "eyebrow", "Label kecil di atas judul", { maxLength: 120 })}</div>
        <div className="form-row">{field("home", "titleFirst", "Baris judul pertama", { maxLength: 100 })}{field("home", "titleSecond", "Baris judul kedua", { maxLength: 100 })}</div>
        {area("home", "intro", "Perkenalan singkat", 3)}<div className="form-row">{field("home", "primaryCta", "Tombol utama", { maxLength: 80 })}{field("home", "secondaryCta", "Tombol kedua", { maxLength: 80 })}</div>
        {field("home", "note", "Catatan di bawah tombol", { maxLength: 180 })}
        {field("home", "artCaption", "Keterangan foto Beranda", { maxLength: 120 })}
        <h3 className="admin-form-section-title">Foto Beranda</h3><p className="admin-page-hint">Foto ini terpisah dari Tentang. Pilih foto, atur crop dan rasio, lalu simpan halaman.</p>
        <div className="admin-hero-preview"><Image src={content.home.heroImage || "/images/reza-sahendra.jpg"} alt="Pratinjau foto Beranda" width={320} height={400} style={{ aspectRatio: cropRatios[validCropRatio(content.home.heroAspect, "4:5")] }} unoptimized/></div>
        <div className="editor-actions"><label className="button button-quiet admin-upload-button">{uploading === "hero" ? "Mengunggah…" : content.home.heroImage ? "Ganti dan crop foto Beranda" : "Pilih dan crop foto Beranda"}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={Boolean(uploading) || cropJobs.length > 0} onChange={(event) => { chooseHeroImage(event.target.files?.[0]); event.currentTarget.value = ""; }}/></label><button className="button button-quiet" type="button" disabled={Boolean(uploading)} onClick={() => void recropPhoto("hero", content.home.heroImage || "/images/reza-sahendra.jpg")}>Crop ulang foto ini</button>{content.home.heroImage && <button className="button button-quiet" type="button" onClick={() => { update("home", "heroImage", ""); update("home", "heroAspect", "4:5"); }}>Gunakan foto bawaan Beranda</button>}</div>
        {field("home", "heroImageAlt", "Deskripsi aksesibilitas foto", { maxLength: 180 })}
        <h3 className="admin-form-section-title">Navigasi mengambang</h3>{field("navigation", "panelTitle", "Judul panel menu", { maxLength: 80 })}
      </>)}

      {!loading && page === "tentang" && settingsForm(<>
        <div className="form-row">{field("about", "navLabel", "Label menu Tentang", { maxLength: 40 })}{field("about", "kicker", "Label bagian", { maxLength: 80 })}</div>
        <div className="form-row">{field("about", "titleFirst", "Baris judul pertama", { maxLength: 100 })}{field("about", "titleSecond", "Baris judul kedua", { maxLength: 100 })}</div>
        {area("about", "lead", "Profil singkat", 3)}{field("about", "agencyUrl", "Tautan instansi (HTTPS)", { type: "url", maxLength: 500 })}
        {area("about", "body", "Cerita dan pengalaman", 5)}<div className="form-row">{field("about", "linkLabel", "Teks tombol kontak", { maxLength: 120 })}{field("general", "profileCaption", "Keterangan di bawah foto", { maxLength: 40 })}</div>
        <div className="admin-form-section-title"><h3>Foto Tentang</h3><p>Terpisah dari Beranda. Pilih foto lalu atur crop dan rasio.</p></div>
        <div className="admin-photo-upload"><Image src={content.about.portraitSrc || "/images/reza-sahendra.jpg"} alt="Pratinjau foto Tentang" width={120} height={120} style={{ aspectRatio: cropRatios[validCropRatio(content.about.portraitAspect, "1:1")] }} unoptimized/><label className="button button-quiet admin-upload-button">{uploading === "portrait" ? "Mengunggah…" : "Ganti dan crop foto Tentang"}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={Boolean(uploading) || cropJobs.length > 0} onChange={(event) => { choosePortrait(event.target.files?.[0]); event.currentTarget.value = ""; }}/></label><button className="button button-quiet" type="button" disabled={Boolean(uploading)} onClick={() => void recropPhoto("portrait", content.about.portraitSrc || "/images/reza-sahendra.jpg")}>Crop ulang foto ini</button></div>
      </>)}

      {!loading && page === "karya" && <>{settingsForm(<><div className="form-row">{field("works", "navLabel", "Label menu Karya", { maxLength: 40 })}{field("works", "kicker", "Label bagian", { maxLength: 80 })}</div><div className="form-row">{field("works", "title", "Judul bagian", { maxLength: 100 })}{field("works", "description", "Deskripsi bagian", { maxLength: 300 })}</div><div className="form-row">{field("works", "cardPrefix", "Label pada kartu karya", { maxLength: 40 })}{field("works", "projectLinkLabel", "Teks tautan proyek", { maxLength: 80 })}</div><div className="admin-form-section-title"><h3>Jika belum ada karya</h3></div>{field("works", "emptyTitle", "Judul tampilan kosong", { maxLength: 140 })}{field("works", "emptyDescription", "Keterangan tampilan kosong", { maxLength: 300 })}<label className="admin-checkbox"><input type="checkbox" checked={content.works.showDefaultProjects} onChange={(event) => setContent((current) => ({ ...current, works: { ...current.works, showDefaultProjects: event.target.checked } }))}/><span>Tampilkan dua proyek awal jika daftar karya kosong</span></label></>)}{entriesManager("project")}</>}

      {!loading && page === "galeri" && <>
{settingsForm(<><div className="form-row">{field("gallery", "navLabel", "Label menu Galeri", { maxLength: 40 })}{field("gallery", "kicker", "Label bagian", { maxLength: 80 })}</div><div className="form-row">{field("gallery", "title", "Judul bagian", { maxLength: 100 })}{field("gallery", "description", "Deskripsi bagian", { maxLength: 300 })}</div><div className="form-row">{field("gallery", "emptyTitle", "Judul saat galeri kosong", { maxLength: 140 })}{field("gallery", "emptyDescription", "Keterangan saat galeri kosong", { maxLength: 300 })}</div><div className="form-row">{field("gallery", "closeLabel", "Tombol tutup foto", { maxLength: 40 })}{field("gallery", "openPhotoLabel", "Label akses buka foto", { maxLength: 40 })}</div><div className="form-row">{field("gallery", "previousLabel", "Tombol foto sebelumnya", { maxLength: 40 })}{field("gallery", "nextLabel", "Tombol foto berikutnya", { maxLength: 40 })}</div></>)}
        <form className="editor-form admin-gallery-form" onSubmit={saveGallery}><div className="admin-card-head"><div><p className="section-kicker">FOTO GALERI</p><h2>{photos.length} foto</h2></div><label className="button button-quiet admin-upload-button">Tambah dan crop foto<input type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={Boolean(uploading) || cropJobs.length > 0 || photos.length >= 30} onChange={(event) => { addPhotos(event.target.files); event.currentTarget.value = ""; }}/></label></div>
          {cropJobs.length > 1 && <p className="admin-page-hint">Atur foto satu per satu; {cropJobs.length} foto menunggu crop.</p>}
          <div className="admin-photo-list">{photos.map((photo, index) => <article className="admin-photo-item" key={`${photo.src}-${index}`}><Image src={photo.src} alt={photo.alt || "Pratinjau foto galeri"} width={photo.width} height={photo.height} unoptimized/><div className="admin-photo-fields"><TextField label="Keterangan" value={photo.caption} maxLength={180} onChange={(value) => updatePhoto(index, "caption", value)}/><TextField label="Teks aksesibilitas foto" value={photo.alt} maxLength={240} onChange={(value) => updatePhoto(index, "alt", value)}/><div className="editor-actions"><label className="button button-quiet admin-upload-button">{uploading === `replace-${index}` ? "Mengunggah…" : "Ganti dan crop foto"}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={Boolean(uploading) || cropJobs.length > 0} onChange={(event) => { replacePhoto(index, event.target.files?.[0]); event.currentTarget.value = ""; }}/></label><button className="button button-quiet" type="button" disabled={Boolean(uploading)} onClick={() => void recropPhoto("gallery-replace", photo.src, index)}>Crop ulang</button><button className="button button-quiet" type="button" onClick={() => movePhoto(index, -1)} disabled={index === 0}>Naik</button><button className="button button-quiet" type="button" onClick={() => movePhoto(index, 1)} disabled={index === photos.length - 1}>Turun</button><button className="button button-quiet delete-button" type="button" onClick={() => setPhotos((current) => current.filter((_, i) => i !== index))}>Hapus</button></div></div></article>)}</div>
          <div className="editor-actions"><button className="button button-dark" type="submit" disabled={saving}>{saving ? "Menyimpan…" : "Simpan galeri"}</button></div>
        </form>
      </>}

      {!loading && page === "catatan" && <>{settingsForm(<><div className="form-row">{field("blog", "navLabel", "Label menu Catatan", { maxLength: 40 })}{field("blog", "kicker", "Label bagian", { maxLength: 80 })}</div><div className="form-row">{field("blog", "titleFirst", "Baris judul pertama", { maxLength: 100 })}{field("blog", "titleSecond", "Baris judul kedua", { maxLength: 100 })}</div>{area("blog", "description", "Deskripsi bagian", 3)}<div className="form-row">{field("blog", "categoryFallback", "Kategori jika kosong", { maxLength: 60 })}{field("blog", "backLabel", "Teks kembali ke blog", { maxLength: 80 })}</div>{field("blog", "allPostsLabel", "Teks tautan semua tulisan", { maxLength: 80 })}{field("blog", "emptyTitle", "Judul saat belum ada tulisan", { maxLength: 140 })}{area("blog", "emptyDescription", "Keterangan saat belum ada tulisan", 3)}</>)}{entriesManager("post")}</>}

      {!loading && page === "kontak" && <>{settingsForm(<>
        <div className="form-row">{field("contact", "navLabel", "Label menu Kontak", { maxLength: 40 })}{field("contact", "kicker", "Label bagian kontak", { maxLength: 80 })}</div>
        <div className="form-row">{field("contact", "titleFirst", "Baris judul kontak pertama", { maxLength: 100 })}{field("contact", "titleSecond", "Baris judul kontak kedua", { maxLength: 100 })}</div>
        {field("contact", "description", "Keterangan kontak", { maxLength: 300 })}{field("navigation", "contactCta", "Tombol kontak di header", { maxLength: 80 })}
        <h3 className="admin-form-section-title">Formulir pesan</h3><div className="form-row">{field("contact", "formKicker", "Label formulir", { maxLength: 80 })}{field("contact", "submitLabel", "Teks tombol kirim", { maxLength: 80 })}</div>
        <div className="form-row">{field("contact", "formTitleFirst", "Baris judul formulir pertama", { maxLength: 100 })}{field("contact", "formTitleSecond", "Baris judul formulir kedua", { maxLength: 100 })}</div>
        {area("contact", "formDescription", "Keterangan formulir", 3)}<div className="form-row">{field("contact", "nameLabel", "Label nama", { maxLength: 40 })}{field("contact", "namePlaceholder", "Placeholder nama", { maxLength: 80 })}</div>
        <div className="form-row">{field("contact", "emailLabel", "Label email", { maxLength: 40 })}{field("contact", "emailPlaceholder", "Placeholder email", { maxLength: 80 })}</div>
        <div className="form-row">{field("contact", "messageLabel", "Label pesan", { maxLength: 40 })}{field("contact", "messagePlaceholder", "Placeholder pesan", { maxLength: 160 })}</div>
        <div className="form-row">{field("contact", "sendingLabel", "Teks saat mengirim", { maxLength: 80 })}{field("contact", "sentMessage", "Pesan berhasil dikirim", { maxLength: 180 })}</div>{field("contact", "errorMessage", "Pesan gagal dikirim", { maxLength: 180 })}
        <h3 className="admin-form-section-title">Tautan sosial</h3>{field("socials", "openLabel", "Teks tautan sosial", { maxLength: 60 })}
        <div className="social-links-editor">{content.socials.socialLinks.map((link, index) => <article className="social-link-editor" key={link.id}>
          <div className="form-row"><label>Nama tautan<input type="text" maxLength={60} value={link.label} onChange={(event) => updateSocialLink(index, "label", event.target.value)} required/></label><label>Alamat HTTPS<input type="url" maxLength={500} value={link.url} placeholder="https://" onChange={(event) => updateSocialLink(index, "url", event.target.value)} required/></label></div>
          <div className="editor-actions"><button className="button button-quiet" type="button" onClick={() => moveSocialLink(index, -1)} disabled={index === 0}>Naik</button><button className="button button-quiet" type="button" onClick={() => moveSocialLink(index, 1)} disabled={index === content.socials.socialLinks.length - 1}>Turun</button><button className="button button-quiet delete-button" type="button" onClick={() => removeSocialLink(index)}>Hapus tautan</button></div>
        </article>)}</div>
        <div className="editor-actions"><button className="button button-quiet" type="button" onClick={addSocialLink} disabled={content.socials.socialLinks.length >= 20}>Tambah tautan sosial</button><span className="admin-page-hint">Maksimal 20 tautan. Setiap alamat harus menggunakan HTTPS.</span></div>
      </>)}<section className="admin-page-subsection"><div className="admin-card-head"><div><p className="section-kicker">PESAN MASUK</p><h2>Kotak pesan</h2></div><span className="inbox-count">{inbox.length}</span></div>{inbox.length ? <div className="message-list">{inbox.map((message) => <article className="inbox-message" key={message.id}><div className="inbox-meta"><strong>{message.name}</strong><a href={`mailto:${message.email}`}>{message.email}</a><time>{new Date(message.createdAt).toLocaleString("id-ID")}</time></div><p>{message.message}</p></article>)}</div> : <p className="admin-empty">Belum ada pesan.</p>}</section></>}
      {notice && <p className="admin-notice" role="status">{notice}</p>}
    </section>
    {cropJobs[0] && <PhotoCropper key={`${cropJobs[0].file.name}-${cropJobs[0].file.size}-${cropJobs.length}`} file={cropJobs[0].file} title={cropJobs[0].target === "hero" ? "Beranda" : cropJobs[0].target === "portrait" ? "Tentang" : "Album Pribadi"} initialRatio={cropJobs[0].target === "hero" ? validCropRatio(content.home.heroAspect, "4:5") : cropJobs[0].target === "portrait" ? validCropRatio(content.about.portraitAspect, "1:1") : "1:1"} onCancel={closeCrop} onConfirm={applyCrop}/>}
  </div>;
}
