"use client";

import { useEffect, useRef, useState } from "react";

export const cropRatios = { "1:1": 1, "4:5": 4 / 5, "3:4": 3 / 4, "16:9": 16 / 9 } as const;
export type CropRatio = keyof typeof cropRatios;

type Props = {
  file: File;
  title: string;
  initialRatio: CropRatio;
  onCancel: () => void;
  onConfirm: (file: File, ratio: CropRatio) => Promise<void>;
};

export default function PhotoCropper({ file, title, initialRatio, onCancel, onConfirm }: Props) {
  const [ratio, setRatio] = useState<CropRatio>(initialRatio);
  const [zoom, setZoom] = useState(1);
  const [offsetX, setOffsetX] = useState(0);
  const [offsetY, setOffsetY] = useState(0);
  const [ready, setReady] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const imageRef = useRef<HTMLImageElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cancelRef = useRef<HTMLButtonElement>(null);
  const dialogRef = useRef<HTMLElement>(null);
  const savingRef = useRef(false);

  useEffect(() => {
    let active = true;
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => { if (active) { imageRef.current = image; setReady(true); } };
    image.onerror = () => { if (active) setError("Foto belum dapat dibuka. Pilih JPG, PNG, atau WebP."); };
    image.src = url;
    cancelRef.current?.focus();
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !savingRef.current) { event.preventDefault(); onCancel(); }
      if (event.key !== "Tab") return;
      const controls = dialogRef.current?.querySelectorAll<HTMLElement>("button:not(:disabled), select, input:not(:disabled)");
      if (!controls?.length) return;
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => {
      active = false;
      imageRef.current = null;
      URL.revokeObjectURL(url);
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [file, onCancel]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const image = imageRef.current;
    if (!canvas || !image || !ready) return;
    const aspect = cropRatios[ratio];
    const maxSize = 1000;
    canvas.width = aspect >= 1 ? maxSize : Math.round(maxSize * aspect);
    canvas.height = aspect >= 1 ? Math.round(maxSize / aspect) : maxSize;
    const context = canvas.getContext("2d");
    if (!context) return;
    const sourceAspect = image.naturalWidth / image.naturalHeight;
    const baseWidth = sourceAspect > aspect ? image.naturalHeight * aspect : image.naturalWidth;
    const baseHeight = baseWidth / aspect;
    const width = baseWidth / zoom;
    const height = baseHeight / zoom;
    const remainingX = image.naturalWidth - width;
    const remainingY = image.naturalHeight - height;
    const left = remainingX * (offsetX + 1) / 2;
    const top = remainingY * (offsetY + 1) / 2;
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.drawImage(image, left, top, width, height, 0, 0, canvas.width, canvas.height);
  }, [ready, ratio, zoom, offsetX, offsetY]);

  async function saveCrop() {
    const canvas = canvasRef.current;
    if (!canvas || !ready) return;
    savingRef.current = true;
    setSaving(true); setError("");
    try {
      const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error("Crop belum dapat disimpan.")), "image/jpeg", 0.9));
      const name = file.name.replace(/\.[^.]+$/, "");
      await onConfirm(new File([blob], `${name}-crop.jpg`, { type: "image/jpeg" }), ratio);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Crop belum dapat disimpan.");
      savingRef.current = false;
      setSaving(false);
    }
  }

  return <div className="admin-crop-backdrop" role="presentation">
    <section className="admin-crop-dialog" ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="admin-crop-title">
      <h2 id="admin-crop-title">Atur foto {title}</h2>
      <p>Pilih rasio dan geser posisi foto sebelum mengunggah.</p>
      <div className="admin-crop-preview"><canvas ref={canvasRef} aria-label={`Pratinjau crop foto ${title}`} style={{ aspectRatio: cropRatios[ratio] }}/></div>
      <div className="admin-crop-controls">
        <label>Rasio foto<select value={ratio} onChange={(event) => { setRatio(event.target.value as CropRatio); setOffsetX(0); setOffsetY(0); }}><option value="1:1">Persegi 1:1</option><option value="4:5">Potret 4:5</option><option value="3:4">Potret 3:4</option><option value="16:9">Lebar 16:9</option></select></label>
        <label>Perbesar<input type="range" min="1" max="2.5" step="0.01" value={zoom} onChange={(event) => setZoom(Number(event.target.value))}/></label>
        <label>Geser kiri–kanan<input type="range" min="-1" max="1" step="0.01" value={offsetX} onChange={(event) => setOffsetX(Number(event.target.value))}/></label>
        <label>Geser atas–bawah<input type="range" min="-1" max="1" step="0.01" value={offsetY} onChange={(event) => setOffsetY(Number(event.target.value))}/></label>
      </div>
      {error && <p className="admin-crop-error" role="alert">{error}</p>}
      <div className="editor-actions"><button ref={cancelRef} className="button button-quiet" type="button" disabled={saving} onClick={onCancel}>Batal</button><button className="button button-dark" type="button" disabled={!ready || saving} onClick={() => void saveCrop()}>{saving ? "Mengunggah…" : "Pakai foto ini"}</button></div>
    </section>
  </div>;
}
