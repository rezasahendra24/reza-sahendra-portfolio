export const adminCookieName = "__Host-reza-admin-pin";
const sessionSeconds = 8 * 60 * 60;
const cookieOptions = "Path=/; HttpOnly; Secure; SameSite=Strict";

async function sessionKey() {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret) throw new Error("Admin session secret is missing.");
  return crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

function hex(bytes: Uint8Array) {
  return Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
}

function sessionData(owner: string, payload: string) {
  return new TextEncoder().encode(JSON.stringify(["admin-pin-session-v1", owner, payload]));
}

export async function createAdminSessionCookie(owner: string) {
  const expires = Math.floor(Date.now() / 1000) + sessionSeconds;
  const nonce = hex(crypto.getRandomValues(new Uint8Array(16)));
  const payload = `${expires}.${nonce}`;
  const signature = await crypto.subtle.sign("HMAC", await sessionKey(), sessionData(owner, payload));
  return `${adminCookieName}=${payload}.${hex(new Uint8Array(signature))}; Max-Age=${sessionSeconds}; ${cookieOptions}`;
}

export function clearAdminSessionCookie() {
  return `${adminCookieName}=; Max-Age=0; ${cookieOptions}`;
}

export async function hasValidAdminSession(cookieHeader: string | null, owner: string) {
  const prefix = adminCookieName + "=";
  const cookie = cookieHeader?.split(";").map(part => part.trim()).find(part => part.startsWith(prefix));
  const parts = cookie?.slice(prefix.length).match(/^(\d{10})\.([a-f0-9]{32})\.([a-f0-9]{64})$/);
  if (!parts || !process.env.ADMIN_SESSION_SECRET) return false;
  const expires = Number(parts[1]);
  const now = Math.floor(Date.now() / 1000);
  if (expires <= now || expires > now + sessionSeconds + 60) return false;
  const signature = Uint8Array.from(parts[3].match(/../g)!, pair => parseInt(pair, 16));
  return crypto.subtle.verify("HMAC", await sessionKey(), signature, sessionData(owner, `${parts[1]}.${parts[2]}`));
}
