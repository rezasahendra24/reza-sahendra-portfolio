import type { Metadata } from "next";
import { getSiteContent } from "@/lib/site-content";
import "./globals.css";
import "./portfolio.css";

export async function generateMetadata(): Promise<Metadata> {
  const content = await getSiteContent();
  return {
    metadataBase: new URL("https://rezasahendra.netlify.app"),
    verification: { google: "3DwVLYYZOsKs943qjJ53Lvogp_JllmFdGhUmFYuNur8" },
    title: content.general.siteTitle,
    description: content.general.siteDescription,
    openGraph: {
      type: "website",
      locale: "id_ID",
      siteName: content.general.brandName,
      title: content.general.siteTitle,
      description: content.general.siteDescription,
      images: ["/images/reza-sahendra.jpg"],
    },
    twitter: { card: "summary_large_image", title: content.general.siteTitle, description: content.general.siteDescription, images: ["/images/reza-sahendra.jpg"] },
    icons: {
      icon: [{ url: "/favicon.png", sizes: "512x512", type: "image/png" }],
      shortcut: "/favicon.ico",
      apple: "/apple-touch-icon.png",
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body className="antialiased">{children}</body>
    </html>
  );
}
