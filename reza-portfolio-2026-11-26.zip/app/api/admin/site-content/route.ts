import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { siteSettings } from "@/db/schema";
import { defaultSiteContent, normalizeSiteContent } from "@/lib/site-content-defaults";
import { ownerApiError, sameOriginRequest } from "@/lib/owner-auth";

export async function GET(request: Request) {
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const [row] = await getDb().select().from(siteSettings).where(eq(siteSettings.key, "content")).limit(1);
    const content = row ? normalizeSiteContent(JSON.parse(row.value)) : defaultSiteContent;
    return Response.json({ content }, { headers: { "cache-control": "no-store" } });
  } catch (cause) {
    console.error("Admin site content read failed", cause);
    return Response.json({ error: "Pengaturan situs belum dapat dimuat." }, { status: 503 });
  }
}

export async function PUT(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: "Permintaan tidak valid." }, { status: 403 });
  const denied = await ownerApiError(request);
  if (denied) return denied;
  try {
    const body = await request.json() as { content?: unknown };
    const content = normalizeSiteContent(body.content);
    const now = new Date().toISOString();
    await getDb().insert(siteSettings).values({ key: "content", value: JSON.stringify(content), updatedAt: now })
      .onConflictDoUpdate({ target: siteSettings.key, set: { value: JSON.stringify(content), updatedAt: now } });
    return Response.json({ content, message: "Pengaturan halaman tersimpan." }, { headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "Pengaturan halaman belum dapat disimpan." }, { status: 400 });
  }
}
